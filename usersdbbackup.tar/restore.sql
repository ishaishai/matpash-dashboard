--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE usersdb;
--
-- Name: usersdb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE usersdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Israel.1252' LC_CTYPE = 'English_Israel.1252';


ALTER DATABASE usersdb OWNER TO matpash;

\connect usersdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eventsTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."eventsTable" (
    username text NOT NULL,
    operation text NOT NULL,
    date text NOT NULL
);


ALTER TABLE public."eventsTable" OWNER TO postgres;

--
-- Name: usersInfoTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."usersInfoTable" (
    username text NOT NULL,
    password text,
    id text NOT NULL,
    "firstName" text,
    "lastName" text,
    role text NOT NULL,
    organization text,
    permissions text
);


ALTER TABLE public."usersInfoTable" OWNER TO postgres;

--
-- Name: usersPriviledgesTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."usersPriviledgesTable" (
    id text NOT NULL,
    print boolean NOT NULL,
    pdf boolean NOT NULL,
    image boolean NOT NULL
);


ALTER TABLE public."usersPriviledgesTable" OWNER TO postgres;

--
-- Data for Name: eventsTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."eventsTable" (username, operation, date) FROM stdin;
\.
COPY public."eventsTable" (username, operation, date) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: usersInfoTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."usersInfoTable" (username, password, id, "firstName", "lastName", role, organization, permissions) FROM stdin;
\.
COPY public."usersInfoTable" (username, password, id, "firstName", "lastName", role, organization, permissions) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: usersPriviledgesTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."usersPriviledgesTable" (id, print, pdf, image) FROM stdin;
\.
COPY public."usersPriviledgesTable" (id, print, pdf, image) FROM '$$PATH$$/2830.dat';

--
-- Name: usersInfoTable usersInfoTable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."usersInfoTable"
    ADD CONSTRAINT "usersInfoTable_pkey" PRIMARY KEY (id);


--
-- Name: usersInfoTable usersInfoTable_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."usersInfoTable"
    ADD CONSTRAINT "usersInfoTable_username_key" UNIQUE (username);


--
-- Name: usersPriviledgesTable fk_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."usersPriviledgesTable"
    ADD CONSTRAINT fk_id FOREIGN KEY (id) REFERENCES public."usersInfoTable"(id);


--
-- Name: eventsTable fk_username; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."eventsTable"
    ADD CONSTRAINT fk_username FOREIGN KEY (username) REFERENCES public."usersInfoTable"(username);


--
-- PostgreSQL database dump complete
--

