--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE maindb;
--
-- Name: maindb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE maindb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE maindb OWNER TO matpash;

\connect maindb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: גירעון עזה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גירעון עזה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."גירעון עזה" OWNER TO matpash;

--
-- Name: גירעון עזה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גירעון עזה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."גירעון עזה - KV" OWNER TO matpash;

--
-- Name: גרף תקציב; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף תקציב" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."גרף תקציב" OWNER TO matpash;

--
-- Name: גרף תקציב - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף תקציב - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."גרף תקציב - KV" OWNER TO matpash;

--
-- Name: תקציב חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."תקציב חודשי" OWNER TO matpash;

--
-- Name: תקציב חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."תקציב חודשי - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-גרעון ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-גרעון " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-גרעון " OWNER TO matpash;

--
-- Name: תקציב שנתי-גרעון  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-גרעון  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-גרעון  - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-הוצאות ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הוצאות " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הוצאות " OWNER TO matpash;

--
-- Name: תקציב שנתי-הוצאות  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הוצאות  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הוצאות  - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-הכנסותת ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הכנסותת " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הכנסותת " OWNER TO matpash;

--
-- Name: תקציב שנתי-הכנסותת  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הכנסותת  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הכנסותת  - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-סיוע חוץ ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-סיוע חוץ " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-סיוע חוץ " OWNER TO matpash;

--
-- Name: תקציב שנתי-סיוע חוץ  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-סיוע חוץ  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-סיוע חוץ  - KV" OWNER TO matpash;

--
-- Data for Name: גירעון עזה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גירעון עזה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."גירעון עזה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/2887.dat';

--
-- Data for Name: גירעון עזה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גירעון עזה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."גירעון עזה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/2888.dat';

--
-- Data for Name: גרף תקציב; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף תקציב" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."גרף תקציב" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/2889.dat';

--
-- Data for Name: גרף תקציב - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף תקציב - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."גרף תקציב - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/2890.dat';

--
-- Data for Name: תקציב חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב חודשי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."תקציב חודשי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/2885.dat';

--
-- Data for Name: תקציב חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."תקציב חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/2886.dat';

--
-- Data for Name: תקציב שנתי-גרעון ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-גרעון " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-גרעון " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/2883.dat';

--
-- Data for Name: תקציב שנתי-גרעון  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-גרעון  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-גרעון  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/2884.dat';

--
-- Data for Name: תקציב שנתי-הוצאות ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הוצאות " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-הוצאות " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/2879.dat';

--
-- Data for Name: תקציב שנתי-הוצאות  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הוצאות  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-הוצאות  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/2880.dat';

--
-- Data for Name: תקציב שנתי-הכנסותת ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הכנסותת " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-הכנסותת " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/2877.dat';

--
-- Data for Name: תקציב שנתי-הכנסותת  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הכנסותת  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-הכנסותת  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/2878.dat';

--
-- Data for Name: תקציב שנתי-סיוע חוץ ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-סיוע חוץ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-סיוע חוץ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/2881.dat';

--
-- Data for Name: תקציב שנתי-סיוע חוץ  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-סיוע חוץ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-סיוע חוץ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/2882.dat';

--
-- PostgreSQL database dump complete
--

