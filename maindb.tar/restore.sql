--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE maindb;
--
-- Name: maindb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE maindb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Israel.1252' LC_CTYPE = 'English_Israel.1252';


ALTER DATABASE maindb OWNER TO matpash;

\connect maindb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: 2019 ייצור תעשייתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."2019 ייצור תעשייתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."2019 ייצור תעשייתי" OWNER TO matpash;

--
-- Name: 2019 ייצור תעשייתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."2019 ייצור תעשייתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."2019 ייצור תעשייתי - KV" OWNER TO matpash;

--
-- Name: איוש מחירים-חודש מקביל %; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-חודש מקביל %" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."איוש מחירים-חודש מקביל %" OWNER TO matpash;

--
-- Name: איוש מחירים-חודש מקביל % - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-חודש מקביל % - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."איוש מחירים-חודש מקביל % - KV" OWNER TO matpash;

--
-- Name: איוש מחירים-חודש קודם %; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-חודש קודם %" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."איוש מחירים-חודש קודם %" OWNER TO matpash;

--
-- Name: איוש מחירים-חודש קודם % - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-חודש קודם % - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."איוש מחירים-חודש קודם % - KV" OWNER TO matpash;

--
-- Name: איוש מחירים-מדד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-מדד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."איוש מחירים-מדד" OWNER TO matpash;

--
-- Name: איוש מחירים-מדד - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש מחירים-מדד - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."איוש מחירים-מדד - KV" OWNER TO matpash;

--
-- Name: אשראי מסוכן; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."אשראי מסוכן" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."אשראי מסוכן" OWNER TO matpash;

--
-- Name: אשראי מסוכן - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."אשראי מסוכן - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."אשראי מסוכן - KV" OWNER TO matpash;

--
-- Name: גירעון עזה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גירעון עזה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."גירעון עזה" OWNER TO matpash;

--
-- Name: גירעון עזה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גירעון עזה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."גירעון עזה - KV" OWNER TO matpash;

--
-- Name: גרף ייצור תעשייתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף ייצור תעשייתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."גרף ייצור תעשייתי" OWNER TO matpash;

--
-- Name: גרף ייצור תעשייתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף ייצור תעשייתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."גרף ייצור תעשייתי - KV" OWNER TO matpash;

--
-- Name: גרף תקציב; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף תקציב" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."גרף תקציב" OWNER TO matpash;

--
-- Name: גרף תקציב - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."גרף תקציב - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."גרף תקציב - KV" OWNER TO matpash;

--
-- Name: הכנסות שכר-איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-איו""ש" OWNER TO matpash;

--
-- Name: הכנסות שכר-איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-איו""ש - KV" OWNER TO matpash;

--
-- Name: הכנסות שכר-רצ"ע ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-רצ""ע " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-רצ""ע " OWNER TO matpash;

--
-- Name: הכנסות שכר-רצ"ע  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-רצ""ע  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-רצ""ע  - KV" OWNER TO matpash;

--
-- Name: הכנסות שכר-רש"פ ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-רש""פ " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-רש""פ " OWNER TO matpash;

--
-- Name: הכנסות שכר-רש"פ  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות שכר-רש""פ  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."הכנסות שכר-רש""פ  - KV" OWNER TO matpash;

--
-- Name: חברות חדשות באיוש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חברות חדשות באיוש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."חברות חדשות באיוש" OWNER TO matpash;

--
-- Name: חברות חדשות באיוש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חברות חדשות באיוש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."חברות חדשות באיוש - KV" OWNER TO matpash;

--
-- Name: חוב  מוערך; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב  מוערך" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."חוב  מוערך" OWNER TO matpash;

--
-- Name: חוב  מוערך - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב  מוערך - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."חוב  מוערך - KV" OWNER TO matpash;

--
-- Name: חוב מדווח-במ"ד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח-במ""ד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח-במ""ד" OWNER TO matpash;

--
-- Name: חוב מדווח-במ"ד - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח-במ""ד - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח-במ""ד - KV" OWNER TO matpash;

--
-- Name: חוב מדווח-בש"ח; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח-בש""ח" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח-בש""ח" OWNER TO matpash;

--
-- Name: חוב מדווח-בש"ח - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח-בש""ח - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח-בש""ח - KV" OWNER TO matpash;

--
-- Name: יחס אשראי לפיקדונות גזרות; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי לפיקדונות גזרות" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."יחס אשראי לפיקדונות גזרות" OWNER TO matpash;

--
-- Name: יחס אשראי לפיקדונות גזרות - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי לפיקדונות גזרות - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."יחס אשראי לפיקדונות גזרות - KV" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדון חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדון חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדון חודשי" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדון חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדון חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדון חודשי - KV" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדונות שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדונות שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדונות שנתי" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדונות שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדונות שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדונות שנתי - KV" OWNER TO matpash;

--
-- Name: יחס גירעון תוצר; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס גירעון תוצר" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."יחס גירעון תוצר" OWNER TO matpash;

--
-- Name: יחס גירעון תוצר - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס גירעון תוצר - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."יחס גירעון תוצר - KV" OWNER TO matpash;

--
-- Name: יחס הלימות הון; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס הלימות הון" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."יחס הלימות הון" OWNER TO matpash;

--
-- Name: יחס הלימות הון - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס הלימות הון - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."יחס הלימות הון - KV" OWNER TO matpash;

--
-- Name: יחס חוב תוצר; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס חוב תוצר" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."יחס חוב תוצר" OWNER TO matpash;

--
-- Name: יחס חוב תוצר - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס חוב תוצר - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."יחס חוב תוצר - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2011; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2011" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2011" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2011 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2011 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2011 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2012; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2012" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2012" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2012 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2012 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2012 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2013; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2013" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2013" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2013 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2013 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2013 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2014; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2014" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2014" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2014 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2014 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2014 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2015; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2015" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2015" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2015 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2015 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2015 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2016; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2016" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2016" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2016 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2016 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2016 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2017; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2017" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2017" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2017 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2017 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2017 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2018; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2018" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2018" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2018 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2018 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2018 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2020; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2020" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2020" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2020 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2020 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2020 - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-איו"ש-מספר ה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-איו""ש-מספר ה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-איו""ש-מספר ה" OWNER TO matpash;

--
-- Name: לא בכח העבודה-איו"ש-מספר ה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-איו""ש-מספר ה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-איו""ש-מספר ה - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-איו"ש-שיעור ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-איו""ש-שיעור " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-איו""ש-שיעור " OWNER TO matpash;

--
-- Name: לא בכח העבודה-איו"ש-שיעור  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-איו""ש-שיעור  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-איו""ש-שיעור  - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רצ"ע-מספר הא; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רצ""ע-מספר הא" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רצ""ע-מספר הא" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רצ"ע-מספר הא - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רצ""ע-מספר הא - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רצ""ע-מספר הא - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רצ"ע-שיעור מ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רצ""ע-שיעור מ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רצ""ע-שיעור מ" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רצ"ע-שיעור מ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רצ""ע-שיעור מ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רצ""ע-שיעור מ - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רש"פ-מספר הא; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רש""פ-מספר הא" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רש""פ-מספר הא" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רש"פ-מספר הא - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רש""פ-מספר הא - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רש""פ-מספר הא - KV" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רש"פ-שיעור מ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רש""פ-שיעור מ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רש""פ-שיעור מ" OWNER TO matpash;

--
-- Name: לא בכח העבודה-רש"פ-שיעור מ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."לא בכח העבודה-רש""פ-שיעור מ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."לא בכח העבודה-רש""פ-שיעור מ - KV" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן שנתי" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן שנתי - KV" OWNER TO matpash;

--
-- Name: מחזור העסקים חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מחזור העסקים חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."מחזור העסקים חודשי" OWNER TO matpash;

--
-- Name: מחזור העסקים חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מחזור העסקים חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."מחזור העסקים חודשי - KV" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-איו"ש ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-איו""ש " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-איו""ש " OWNER TO matpash;

--
-- Name: נעדרים מעבודה-איו"ש  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-איו""ש  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-איו""ש  - KV" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-ישראל; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-ישראל" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-ישראל" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-ישראל - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-ישראל - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-ישראל - KV" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-רצ"ע ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-רצ""ע " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-רצ""ע " OWNER TO matpash;

--
-- Name: נעדרים מעבודה-רצ"ע  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-רצ""ע  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-רצ""ע  - KV" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-רש""פ" OWNER TO matpash;

--
-- Name: נעדרים מעבודה-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נעדרים מעבודה-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."נעדרים מעבודה-רש""פ - KV" OWNER TO matpash;

--
-- Name: נתונים שנתיים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתונים שנתיים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."נתונים שנתיים" OWNER TO matpash;

--
-- Name: נתונים שנתיים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתונים שנתיים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."נתונים שנתיים - KV" OWNER TO matpash;

--
-- Name: סחר חוץ חודשי-יבוא לרש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ חודשי-יבוא לרש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."סחר חוץ חודשי-יבוא לרש""פ" OWNER TO matpash;

--
-- Name: סחר חוץ חודשי-יבוא לרש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ חודשי-יבוא לרש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."סחר חוץ חודשי-יבוא לרש""פ - KV" OWNER TO matpash;

--
-- Name: סחר חוץ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."סחר חוץ שנתי" OWNER TO matpash;

--
-- Name: סחר חוץ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."סחר חוץ שנתי - KV" OWNER TO matpash;

--
-- Name: עוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."עוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."עוני" OWNER TO matpash;

--
-- Name: עוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."עוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."עוני - KV" OWNER TO matpash;

--
-- Name: צקים חוזרים חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255)
);


ALTER TABLE public."צקים חוזרים חודשי" OWNER TO matpash;

--
-- Name: צקים חוזרים חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255)
);


ALTER TABLE public."צקים חוזרים חודשי - KV" OWNER TO matpash;

--
-- Name: צקים חוזרים שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים שנתי" OWNER TO matpash;

--
-- Name: צקים חוזרים שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים שנתי - KV" OWNER TO matpash;

--
-- Name: רצע מחירים-חודש מקביל %; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-חודש מקביל %" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רצע מחירים-חודש מקביל %" OWNER TO matpash;

--
-- Name: רצע מחירים-חודש מקביל % - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-חודש מקביל % - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רצע מחירים-חודש מקביל % - KV" OWNER TO matpash;

--
-- Name: רצע מחירים-חודש קודם %; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-חודש קודם %" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."רצע מחירים-חודש קודם %" OWNER TO matpash;

--
-- Name: רצע מחירים-חודש קודם % - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-חודש קודם % - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."רצע מחירים-חודש קודם % - KV" OWNER TO matpash;

--
-- Name: רצע מחירים-מדד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-מדד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רצע מחירים-מדד" OWNER TO matpash;

--
-- Name: רצע מחירים-מדד - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע מחירים-מדד - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רצע מחירים-מדד - KV" OWNER TO matpash;

--
-- Name: רשפ מחירים-חודש מקביל %; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ מחירים-חודש מקביל %" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."רשפ מחירים-חודש מקביל %" OWNER TO matpash;

--
-- Name: רשפ מחירים-חודש מקביל % - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ מחירים-חודש מקביל % - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."רשפ מחירים-חודש מקביל % - KV" OWNER TO matpash;

--
-- Name: רשפ מחירים-מדד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ מחירים-מדד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רשפ מחירים-מדד" OWNER TO matpash;

--
-- Name: רשפ מחירים-מדד - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ מחירים-מדד - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."רשפ מחירים-מדד - KV" OWNER TO matpash;

--
-- Name: שכר יומי ממוצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שכר יומי ממוצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255)
);


ALTER TABLE public."שכר יומי ממוצע שנתי" OWNER TO matpash;

--
-- Name: שכר יומי ממוצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שכר יומי ממוצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255)
);


ALTER TABLE public."שכר יומי ממוצע שנתי - KV" OWNER TO matpash;

--
-- Name: שנתי ייצור תעשייתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שנתי ייצור תעשייתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."שנתי ייצור תעשייתי" OWNER TO matpash;

--
-- Name: שנתי ייצור תעשייתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שנתי ייצור תעשייתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."שנתי ייצור תעשייתי - KV" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-איו""ש" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-איו""ש - KV" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-רצ"ע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-רצ""ע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-רצ""ע" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-רצ"ע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-רצ""ע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-רצ""ע - KV" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-רש""פ" OWNER TO matpash;

--
-- Name: תוצר לנפש רבעוני-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש רבעוני-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר לנפש רבעוני-רש""פ - KV" OWNER TO matpash;

--
-- Name: תוצר לנפש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תוצר לנפש שנתי" OWNER TO matpash;

--
-- Name: תוצר לנפש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תוצר לנפש שנתי - KV" OWNER TO matpash;

--
-- Name: תוצר רבעוני-איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-איו""ש" OWNER TO matpash;

--
-- Name: תוצר רבעוני-איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-איו""ש - KV" OWNER TO matpash;

--
-- Name: תוצר רבעוני-נתח יחסי ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-נתח יחסי " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-נתח יחסי " OWNER TO matpash;

--
-- Name: תוצר רבעוני-נתח יחסי  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-נתח יחסי  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-נתח יחסי  - KV" OWNER TO matpash;

--
-- Name: תוצר רבעוני-רצ"ע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-רצ""ע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-רצ""ע" OWNER TO matpash;

--
-- Name: תוצר רבעוני-רצ"ע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-רצ""ע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-רצ""ע - KV" OWNER TO matpash;

--
-- Name: תוצר רבעוני-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-רש""פ" OWNER TO matpash;

--
-- Name: תוצר רבעוני-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר רבעוני-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."תוצר רבעוני-רש""פ - KV" OWNER TO matpash;

--
-- Name: תוצר שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תוצר שנתי" OWNER TO matpash;

--
-- Name: תוצר שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תוצר שנתי - KV" OWNER TO matpash;

--
-- Name: תעסוקה בישראל; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה בישראל" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תעסוקה בישראל" OWNER TO matpash;

--
-- Name: תעסוקה בישראל - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה בישראל - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תעסוקה בישראל - KV" OWNER TO matpash;

--
-- Name: תעסוקה גברים-איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-איו""ש" OWNER TO matpash;

--
-- Name: תעסוקה גברים-איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-איו""ש - KV" OWNER TO matpash;

--
-- Name: תעסוקה גברים-רצ"ע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-רצ""ע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-רצ""ע" OWNER TO matpash;

--
-- Name: תעסוקה גברים-רצ"ע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-רצ""ע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-רצ""ע - KV" OWNER TO matpash;

--
-- Name: תעסוקה גברים-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-רש""פ" OWNER TO matpash;

--
-- Name: תעסוקה גברים-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גברים-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה גברים-רש""פ - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-איו"ש-אחוז האבט; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-איו""ש-אחוז האבט" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-איו""ש-אחוז האבט" OWNER TO matpash;

--
-- Name: תעסוקה גיל-איו"ש-אחוז האבט - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-איו""ש-אחוז האבט - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-איו""ש-אחוז האבט - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-איו"ש-שיעור השת; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-איו""ש-שיעור השת" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-איו""ש-שיעור השת" OWNER TO matpash;

--
-- Name: תעסוקה גיל-איו"ש-שיעור השת - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-איו""ש-שיעור השת - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-איו""ש-שיעור השת - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רצ"ע-אחוז האבטל; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רצ""ע-אחוז האבטל" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רצ""ע-אחוז האבטל" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רצ"ע-אחוז האבטל - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רצ""ע-אחוז האבטל - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רצ""ע-אחוז האבטל - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רצ"ע-שיעור השתת; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רצ""ע-שיעור השתת" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רצ""ע-שיעור השתת" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רצ"ע-שיעור השתת - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רצ""ע-שיעור השתת - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רצ""ע-שיעור השתת - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רש"פ-אחוז האבטל; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רש""פ-אחוז האבטל" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רש""פ-אחוז האבטל" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רש"פ-אחוז האבטל - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רש""פ-אחוז האבטל - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רש""פ-אחוז האבטל - KV" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רש"פ-שיעור השתת; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רש""פ-שיעור השתת" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רש""פ-שיעור השתת" OWNER TO matpash;

--
-- Name: תעסוקה גיל-רש"פ-שיעור השתת - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה גיל-רש""פ-שיעור השתת - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."תעסוקה גיל-רש""פ-שיעור השתת - KV" OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-איו"ש ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-איו""ש " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-איו""ש " OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-איו"ש  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-איו""ש  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-איו""ש  - KV" OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-רצ"ע ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-רצ""ע " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-רצ""ע " OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-רצ"ע  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-רצ""ע  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-רצ""ע  - KV" OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-רש""פ" OWNER TO matpash;

--
-- Name: תעסוקה מועסקים-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מועסקים-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255)
);


ALTER TABLE public."תעסוקה מועסקים-רש""פ - KV" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -איו""ש" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -איו""ש - KV" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -ישראל והתייש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -ישראל והתייש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -ישראל והתייש" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -ישראל והתייש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -ישראל והתייש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -ישראל והתייש - KV" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -רצ"ע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -רצ""ע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -רצ""ע" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -רצ"ע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -רצ""ע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -רצ""ע - KV" OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -רש"פ ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -רש""פ " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -רש""פ " OWNER TO matpash;

--
-- Name: תעסוקה מרכזי -רש"פ  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה מרכזי -רש""פ  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה מרכזי -רש""פ  - KV" OWNER TO matpash;

--
-- Name: תעסוקה נשים-איו"ש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-איו""ש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-איו""ש" OWNER TO matpash;

--
-- Name: תעסוקה נשים-איו"ש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-איו""ש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-איו""ש - KV" OWNER TO matpash;

--
-- Name: תעסוקה נשים-רצ"ע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-רצ""ע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-רצ""ע" OWNER TO matpash;

--
-- Name: תעסוקה נשים-רצ"ע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-רצ""ע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-רצ""ע - KV" OWNER TO matpash;

--
-- Name: תעסוקה נשים-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-רש""פ" OWNER TO matpash;

--
-- Name: תעסוקה נשים-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נשים-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה נשים-רש""פ - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-איו"ש-מספר ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-איו""ש-מספר " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-איו""ש-מספר " OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-איו"ש-מספר  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-איו""ש-מספר  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-איו""ש-מספר  - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-איו"ש-שיעור; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-איו""ש-שיעור" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-איו""ש-שיעור" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-איו"ש-שיעור - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-איו""ש-שיעור - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-איו""ש-שיעור - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רצ"ע-מספר מ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רצ""ע-מספר מ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רצ""ע-מספר מ" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רצ"ע-מספר מ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רצ""ע-מספר מ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רצ""ע-מספר מ - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רצ"ע-שיעור ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רצ""ע-שיעור " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רצ""ע-שיעור " OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רצ"ע-שיעור  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רצ""ע-שיעור  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רצ""ע-שיעור  - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רש"פ-מספר מ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רש""פ-מספר מ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רש""פ-מספר מ" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רש"פ-מספר מ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רש""פ-מספר מ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רש""פ-מספר מ - KV" OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רש"פ-שיעור ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רש""פ-שיעור " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רש""פ-שיעור " OWNER TO matpash;

--
-- Name: תעסוקה סקטורים-רש"פ-שיעור  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה סקטורים-רש""פ-שיעור  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה סקטורים-רש""פ-שיעור  - KV" OWNER TO matpash;

--
-- Name: תעסוקת משכילים-רש"פ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקת משכילים-רש""פ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255)
);


ALTER TABLE public."תעסוקת משכילים-רש""פ" OWNER TO matpash;

--
-- Name: תעסוקת משכילים-רש"פ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקת משכילים-רש""פ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255)
);


ALTER TABLE public."תעסוקת משכילים-רש""פ - KV" OWNER TO matpash;

--
-- Name: תקציב חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."תקציב חודשי" OWNER TO matpash;

--
-- Name: תקציב חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."תקציב חודשי - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-גרעון ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-גרעון " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-גרעון " OWNER TO matpash;

--
-- Name: תקציב שנתי-גרעון  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-גרעון  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-גרעון  - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-הוצאות ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הוצאות " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הוצאות " OWNER TO matpash;

--
-- Name: תקציב שנתי-הוצאות  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הוצאות  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הוצאות  - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-הכנסות; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הכנסות" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הכנסות" OWNER TO matpash;

--
-- Name: תקציב שנתי-הכנסות - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-הכנסות - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-הכנסות - KV" OWNER TO matpash;

--
-- Name: תקציב שנתי-סיוע חוץ ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-סיוע חוץ " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-סיוע חוץ " OWNER TO matpash;

--
-- Name: תקציב שנתי-סיוע חוץ  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תקציב שנתי-סיוע חוץ  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תקציב שנתי-סיוע חוץ  - KV" OWNER TO matpash;

--
-- Data for Name: 2019 ייצור תעשייתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."2019 ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."2019 ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3767.dat';

--
-- Data for Name: 2019 ייצור תעשייתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."2019 ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."2019 ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3768.dat';

--
-- Data for Name: איוש מחירים-חודש מקביל %; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."איוש מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3769.dat';

--
-- Data for Name: איוש מחירים-חודש מקביל % - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."איוש מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3770.dat';

--
-- Data for Name: איוש מחירים-חודש קודם %; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-חודש קודם %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."איוש מחירים-חודש קודם %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3771.dat';

--
-- Data for Name: איוש מחירים-חודש קודם % - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-חודש קודם % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."איוש מחירים-חודש קודם % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3772.dat';

--
-- Data for Name: איוש מחירים-מדד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."איוש מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3773.dat';

--
-- Data for Name: איוש מחירים-מדד - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."איוש מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3774.dat';

--
-- Data for Name: אשראי מסוכן; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."אשראי מסוכן" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."אשראי מסוכן" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3775.dat';

--
-- Data for Name: אשראי מסוכן - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."אשראי מסוכן - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."אשראי מסוכן - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3776.dat';

--
-- Data for Name: גירעון עזה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גירעון עזה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."גירעון עזה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3777.dat';

--
-- Data for Name: גירעון עזה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גירעון עזה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."גירעון עזה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3778.dat';

--
-- Data for Name: גרף ייצור תעשייתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף ייצור תעשייתי" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."גרף ייצור תעשייתי" ("A1", "B1", "C1") FROM '$$PATH$$/3779.dat';

--
-- Data for Name: גרף ייצור תעשייתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף ייצור תעשייתי - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."גרף ייצור תעשייתי - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3780.dat';

--
-- Data for Name: גרף תקציב; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף תקציב" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."גרף תקציב" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3781.dat';

--
-- Data for Name: גרף תקציב - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."גרף תקציב - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."גרף תקציב - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3782.dat';

--
-- Data for Name: הכנסות שכר-איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."הכנסות שכר-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3783.dat';

--
-- Data for Name: הכנסות שכר-איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."הכנסות שכר-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3784.dat';

--
-- Data for Name: הכנסות שכר-רצ"ע ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-רצ""ע " ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."הכנסות שכר-רצ""ע " ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3785.dat';

--
-- Data for Name: הכנסות שכר-רצ"ע  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-רצ""ע  - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."הכנסות שכר-רצ""ע  - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3786.dat';

--
-- Data for Name: הכנסות שכר-רש"פ ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-רש""פ " ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."הכנסות שכר-רש""פ " ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3787.dat';

--
-- Data for Name: הכנסות שכר-רש"פ  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות שכר-רש""פ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."הכנסות שכר-רש""פ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3788.dat';

--
-- Data for Name: חברות חדשות באיוש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חברות חדשות באיוש" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."חברות חדשות באיוש" ("A1", "B1", "C1") FROM '$$PATH$$/3789.dat';

--
-- Data for Name: חברות חדשות באיוש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חברות חדשות באיוש - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."חברות חדשות באיוש - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3790.dat';

--
-- Data for Name: חוב  מוערך; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב  מוערך" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."חוב  מוערך" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3791.dat';

--
-- Data for Name: חוב  מוערך - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב  מוערך - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."חוב  מוערך - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3792.dat';

--
-- Data for Name: חוב מדווח-במ"ד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח-במ""ד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח-במ""ד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3793.dat';

--
-- Data for Name: חוב מדווח-במ"ד - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח-במ""ד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח-במ""ד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3794.dat';

--
-- Data for Name: חוב מדווח-בש"ח; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח-בש""ח" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח-בש""ח" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3795.dat';

--
-- Data for Name: חוב מדווח-בש"ח - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח-בש""ח - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח-בש""ח - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3796.dat';

--
-- Data for Name: יחס אשראי לפיקדונות גזרות; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי לפיקדונות גזרות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."יחס אשראי לפיקדונות גזרות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/3797.dat';

--
-- Data for Name: יחס אשראי לפיקדונות גזרות - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי לפיקדונות גזרות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."יחס אשראי לפיקדונות גזרות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/3798.dat';

--
-- Data for Name: יחס אשראי פיקדון חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדון חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדון חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3799.dat';

--
-- Data for Name: יחס אשראי פיקדון חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדון חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדון חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3800.dat';

--
-- Data for Name: יחס אשראי פיקדונות שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדונות שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדונות שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3801.dat';

--
-- Data for Name: יחס אשראי פיקדונות שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדונות שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדונות שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3802.dat';

--
-- Data for Name: יחס גירעון תוצר; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס גירעון תוצר" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."יחס גירעון תוצר" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3803.dat';

--
-- Data for Name: יחס גירעון תוצר - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס גירעון תוצר - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."יחס גירעון תוצר - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3804.dat';

--
-- Data for Name: יחס הלימות הון; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס הלימות הון" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."יחס הלימות הון" ("A1", "B1", "C1") FROM '$$PATH$$/3805.dat';

--
-- Data for Name: יחס הלימות הון - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס הלימות הון - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."יחס הלימות הון - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3806.dat';

--
-- Data for Name: יחס חוב תוצר; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס חוב תוצר" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."יחס חוב תוצר" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3807.dat';

--
-- Data for Name: יחס חוב תוצר - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס חוב תוצר - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."יחס חוב תוצר - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3808.dat';

--
-- Data for Name: ייצור תעשייתי 2011; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2011" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2011" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3809.dat';

--
-- Data for Name: ייצור תעשייתי 2011 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2011 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2011 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3810.dat';

--
-- Data for Name: ייצור תעשייתי 2012; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2012" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2012" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3811.dat';

--
-- Data for Name: ייצור תעשייתי 2012 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2012 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2012 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3812.dat';

--
-- Data for Name: ייצור תעשייתי 2013; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2013" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2013" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3813.dat';

--
-- Data for Name: ייצור תעשייתי 2013 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2013 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2013 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3814.dat';

--
-- Data for Name: ייצור תעשייתי 2014; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2014" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2014" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3815.dat';

--
-- Data for Name: ייצור תעשייתי 2014 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2014 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2014 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3816.dat';

--
-- Data for Name: ייצור תעשייתי 2015; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2015" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2015" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3817.dat';

--
-- Data for Name: ייצור תעשייתי 2015 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2015 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2015 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3818.dat';

--
-- Data for Name: ייצור תעשייתי 2016; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2016" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2016" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3819.dat';

--
-- Data for Name: ייצור תעשייתי 2016 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2016 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2016 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3820.dat';

--
-- Data for Name: ייצור תעשייתי 2017; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2017" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2017" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3821.dat';

--
-- Data for Name: ייצור תעשייתי 2017 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2017 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2017 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3822.dat';

--
-- Data for Name: ייצור תעשייתי 2018; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2018" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2018" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3823.dat';

--
-- Data for Name: ייצור תעשייתי 2018 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2018 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2018 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3824.dat';

--
-- Data for Name: ייצור תעשייתי 2020; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2020" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2020" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3825.dat';

--
-- Data for Name: ייצור תעשייתי 2020 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2020 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2020 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3826.dat';

--
-- Data for Name: לא בכח העבודה-איו"ש-מספר ה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-איו""ש-מספר ה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."לא בכח העבודה-איו""ש-מספר ה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3827.dat';

--
-- Data for Name: לא בכח העבודה-איו"ש-מספר ה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-איו""ש-מספר ה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."לא בכח העבודה-איו""ש-מספר ה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3828.dat';

--
-- Data for Name: לא בכח העבודה-איו"ש-שיעור ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-איו""ש-שיעור " ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-איו""ש-שיעור " ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3829.dat';

--
-- Data for Name: לא בכח העבודה-איו"ש-שיעור  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-איו""ש-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-איו""ש-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3830.dat';

--
-- Data for Name: לא בכח העבודה-רצ"ע-מספר הא; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רצ""ע-מספר הא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."לא בכח העבודה-רצ""ע-מספר הא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/3831.dat';

--
-- Data for Name: לא בכח העבודה-רצ"ע-מספר הא - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רצ""ע-מספר הא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."לא בכח העבודה-רצ""ע-מספר הא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/3832.dat';

--
-- Data for Name: לא בכח העבודה-רצ"ע-שיעור מ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רצ""ע-שיעור מ" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-רצ""ע-שיעור מ" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3833.dat';

--
-- Data for Name: לא בכח העבודה-רצ"ע-שיעור מ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רצ""ע-שיעור מ - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-רצ""ע-שיעור מ - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3834.dat';

--
-- Data for Name: לא בכח העבודה-רש"פ-מספר הא; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רש""פ-מספר הא" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."לא בכח העבודה-רש""פ-מספר הא" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3835.dat';

--
-- Data for Name: לא בכח העבודה-רש"פ-מספר הא - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רש""פ-מספר הא - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."לא בכח העבודה-רש""פ-מספר הא - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3836.dat';

--
-- Data for Name: לא בכח העבודה-רש"פ-שיעור מ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רש""פ-שיעור מ" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-רש""פ-שיעור מ" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3837.dat';

--
-- Data for Name: לא בכח העבודה-רש"פ-שיעור מ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."לא בכח העבודה-רש""פ-שיעור מ - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."לא בכח העבודה-רש""פ-שיעור מ - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3838.dat';

--
-- Data for Name: מדד המחירים לצרכן שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3839.dat';

--
-- Data for Name: מדד המחירים לצרכן שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3840.dat';

--
-- Data for Name: מחזור העסקים חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מחזור העסקים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."מחזור העסקים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3841.dat';

--
-- Data for Name: מחזור העסקים חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מחזור העסקים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."מחזור העסקים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3842.dat';

--
-- Data for Name: נעדרים מעבודה-איו"ש ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-איו""ש " ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."נעדרים מעבודה-איו""ש " ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3843.dat';

--
-- Data for Name: נעדרים מעבודה-איו"ש  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-איו""ש  - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."נעדרים מעבודה-איו""ש  - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3844.dat';

--
-- Data for Name: נעדרים מעבודה-ישראל; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-ישראל" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."נעדרים מעבודה-ישראל" ("A1", "B1", "C1") FROM '$$PATH$$/3845.dat';

--
-- Data for Name: נעדרים מעבודה-ישראל - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-ישראל - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."נעדרים מעבודה-ישראל - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3846.dat';

--
-- Data for Name: נעדרים מעבודה-רצ"ע ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-רצ""ע " ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."נעדרים מעבודה-רצ""ע " ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3847.dat';

--
-- Data for Name: נעדרים מעבודה-רצ"ע  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-רצ""ע  - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."נעדרים מעבודה-רצ""ע  - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3848.dat';

--
-- Data for Name: נעדרים מעבודה-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-רש""פ" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."נעדרים מעבודה-רש""פ" ("A1", "B1", "C1") FROM '$$PATH$$/3849.dat';

--
-- Data for Name: נעדרים מעבודה-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נעדרים מעבודה-רש""פ - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."נעדרים מעבודה-רש""פ - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3850.dat';

--
-- Data for Name: נתונים שנתיים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתונים שנתיים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."נתונים שנתיים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3851.dat';

--
-- Data for Name: נתונים שנתיים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתונים שנתיים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."נתונים שנתיים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3852.dat';

--
-- Data for Name: סחר חוץ חודשי-יבוא לרש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ חודשי-יבוא לרש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."סחר חוץ חודשי-יבוא לרש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3853.dat';

--
-- Data for Name: סחר חוץ חודשי-יבוא לרש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ חודשי-יבוא לרש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."סחר חוץ חודשי-יבוא לרש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3854.dat';

--
-- Data for Name: סחר חוץ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."סחר חוץ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3855.dat';

--
-- Data for Name: סחר חוץ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."סחר חוץ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3856.dat';

--
-- Data for Name: עוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."עוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."עוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3857.dat';

--
-- Data for Name: עוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."עוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."עוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3858.dat';

--
-- Data for Name: צקים חוזרים חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM stdin;
\.
COPY public."צקים חוזרים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM '$$PATH$$/3859.dat';

--
-- Data for Name: צקים חוזרים חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM stdin;
\.
COPY public."צקים חוזרים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM '$$PATH$$/3860.dat';

--
-- Data for Name: צקים חוזרים שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3861.dat';

--
-- Data for Name: צקים חוזרים שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3862.dat';

--
-- Data for Name: רצע מחירים-חודש מקביל %; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רצע מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3863.dat';

--
-- Data for Name: רצע מחירים-חודש מקביל % - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רצע מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3864.dat';

--
-- Data for Name: רצע מחירים-חודש קודם %; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-חודש קודם %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."רצע מחירים-חודש קודם %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3865.dat';

--
-- Data for Name: רצע מחירים-חודש קודם % - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-חודש קודם % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."רצע מחירים-חודש קודם % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3866.dat';

--
-- Data for Name: רצע מחירים-מדד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רצע מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3867.dat';

--
-- Data for Name: רצע מחירים-מדד - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רצע מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3868.dat';

--
-- Data for Name: רשפ מחירים-חודש מקביל %; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."רשפ מחירים-חודש מקביל %" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3869.dat';

--
-- Data for Name: רשפ מחירים-חודש מקביל % - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."רשפ מחירים-חודש מקביל % - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3870.dat';

--
-- Data for Name: רשפ מחירים-מדד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רשפ מחירים-מדד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3871.dat';

--
-- Data for Name: רשפ מחירים-מדד - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."רשפ מחירים-מדד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3872.dat';

--
-- Data for Name: שכר יומי ממוצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שכר יומי ממוצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM stdin;
\.
COPY public."שכר יומי ממוצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM '$$PATH$$/3873.dat';

--
-- Data for Name: שכר יומי ממוצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שכר יומי ממוצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM stdin;
\.
COPY public."שכר יומי ממוצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM '$$PATH$$/3874.dat';

--
-- Data for Name: שנתי ייצור תעשייתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שנתי ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."שנתי ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3875.dat';

--
-- Data for Name: שנתי ייצור תעשייתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שנתי ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."שנתי ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3876.dat';

--
-- Data for Name: תוצר לנפש רבעוני-איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-איו""ש" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-איו""ש" ("A1", "B1", "C1") FROM '$$PATH$$/3877.dat';

--
-- Data for Name: תוצר לנפש רבעוני-איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-איו""ש - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-איו""ש - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3878.dat';

--
-- Data for Name: תוצר לנפש רבעוני-רצ"ע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-רצ""ע" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-רצ""ע" ("A1", "B1", "C1") FROM '$$PATH$$/3879.dat';

--
-- Data for Name: תוצר לנפש רבעוני-רצ"ע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-רצ""ע - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-רצ""ע - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3880.dat';

--
-- Data for Name: תוצר לנפש רבעוני-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-רש""פ" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-רש""פ" ("A1", "B1", "C1") FROM '$$PATH$$/3881.dat';

--
-- Data for Name: תוצר לנפש רבעוני-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש רבעוני-רש""פ - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר לנפש רבעוני-רש""פ - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3882.dat';

--
-- Data for Name: תוצר לנפש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תוצר לנפש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3883.dat';

--
-- Data for Name: תוצר לנפש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תוצר לנפש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3884.dat';

--
-- Data for Name: תוצר רבעוני-איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-איו""ש" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-איו""ש" ("A1", "B1", "C1") FROM '$$PATH$$/3885.dat';

--
-- Data for Name: תוצר רבעוני-איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-איו""ש - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-איו""ש - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3886.dat';

--
-- Data for Name: תוצר רבעוני-נתח יחסי ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-נתח יחסי " ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-נתח יחסי " ("A1", "B1", "C1") FROM '$$PATH$$/3887.dat';

--
-- Data for Name: תוצר רבעוני-נתח יחסי  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-נתח יחסי  - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-נתח יחסי  - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3888.dat';

--
-- Data for Name: תוצר רבעוני-רצ"ע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-רצ""ע" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-רצ""ע" ("A1", "B1", "C1") FROM '$$PATH$$/3889.dat';

--
-- Data for Name: תוצר רבעוני-רצ"ע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-רצ""ע - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-רצ""ע - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3890.dat';

--
-- Data for Name: תוצר רבעוני-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-רש""פ" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-רש""פ" ("A1", "B1", "C1") FROM '$$PATH$$/3891.dat';

--
-- Data for Name: תוצר רבעוני-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר רבעוני-רש""פ - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."תוצר רבעוני-רש""פ - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3892.dat';

--
-- Data for Name: תוצר שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תוצר שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3893.dat';

--
-- Data for Name: תוצר שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תוצר שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3894.dat';

--
-- Data for Name: תעסוקה בישראל; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה בישראל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תעסוקה בישראל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3895.dat';

--
-- Data for Name: תעסוקה בישראל - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה בישראל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תעסוקה בישראל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3896.dat';

--
-- Data for Name: תעסוקה גברים-איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3897.dat';

--
-- Data for Name: תעסוקה גברים-איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3898.dat';

--
-- Data for Name: תעסוקה גברים-רצ"ע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3899.dat';

--
-- Data for Name: תעסוקה גברים-רצ"ע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3900.dat';

--
-- Data for Name: תעסוקה גברים-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3901.dat';

--
-- Data for Name: תעסוקה גברים-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גברים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה גברים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3902.dat';

--
-- Data for Name: תעסוקה גיל-איו"ש-אחוז האבט; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-איו""ש-אחוז האבט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-איו""ש-אחוז האבט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3903.dat';

--
-- Data for Name: תעסוקה גיל-איו"ש-אחוז האבט - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-איו""ש-אחוז האבט - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-איו""ש-אחוז האבט - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3904.dat';

--
-- Data for Name: תעסוקה גיל-איו"ש-שיעור השת; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-איו""ש-שיעור השת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-איו""ש-שיעור השת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3905.dat';

--
-- Data for Name: תעסוקה גיל-איו"ש-שיעור השת - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-איו""ש-שיעור השת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-איו""ש-שיעור השת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3906.dat';

--
-- Data for Name: תעסוקה גיל-רצ"ע-אחוז האבטל; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רצ""ע-אחוז האבטל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רצ""ע-אחוז האבטל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3907.dat';

--
-- Data for Name: תעסוקה גיל-רצ"ע-אחוז האבטל - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רצ""ע-אחוז האבטל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רצ""ע-אחוז האבטל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3908.dat';

--
-- Data for Name: תעסוקה גיל-רצ"ע-שיעור השתת; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רצ""ע-שיעור השתת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רצ""ע-שיעור השתת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3909.dat';

--
-- Data for Name: תעסוקה גיל-רצ"ע-שיעור השתת - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רצ""ע-שיעור השתת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רצ""ע-שיעור השתת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3910.dat';

--
-- Data for Name: תעסוקה גיל-רש"פ-אחוז האבטל; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רש""פ-אחוז האבטל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רש""פ-אחוז האבטל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3911.dat';

--
-- Data for Name: תעסוקה גיל-רש"פ-אחוז האבטל - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רש""פ-אחוז האבטל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רש""פ-אחוז האבטל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3912.dat';

--
-- Data for Name: תעסוקה גיל-רש"פ-שיעור השתת; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רש""פ-שיעור השתת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רש""פ-שיעור השתת" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3913.dat';

--
-- Data for Name: תעסוקה גיל-רש"פ-שיעור השתת - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה גיל-רש""פ-שיעור השתת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."תעסוקה גיל-רש""פ-שיעור השתת - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3914.dat';

--
-- Data for Name: תעסוקה מועסקים-איו"ש ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-איו""ש " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-איו""ש " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/3915.dat';

--
-- Data for Name: תעסוקה מועסקים-איו"ש  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-איו""ש  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-איו""ש  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/3916.dat';

--
-- Data for Name: תעסוקה מועסקים-רצ"ע ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-רצ""ע " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-רצ""ע " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM '$$PATH$$/3917.dat';

--
-- Data for Name: תעסוקה מועסקים-רצ"ע  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-רצ""ע  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-רצ""ע  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM '$$PATH$$/3918.dat';

--
-- Data for Name: תעסוקה מועסקים-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM '$$PATH$$/3919.dat';

--
-- Data for Name: תעסוקה מועסקים-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מועסקים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM stdin;
\.
COPY public."תעסוקה מועסקים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM '$$PATH$$/3920.dat';

--
-- Data for Name: תעסוקה מרכזי -איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3921.dat';

--
-- Data for Name: תעסוקה מרכזי -איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3922.dat';

--
-- Data for Name: תעסוקה מרכזי -ישראל והתייש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -ישראל והתייש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -ישראל והתייש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3923.dat';

--
-- Data for Name: תעסוקה מרכזי -ישראל והתייש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -ישראל והתייש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -ישראל והתייש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3924.dat';

--
-- Data for Name: תעסוקה מרכזי -רצ"ע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3925.dat';

--
-- Data for Name: תעסוקה מרכזי -רצ"ע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3926.dat';

--
-- Data for Name: תעסוקה מרכזי -רש"פ ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -רש""פ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -רש""פ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3927.dat';

--
-- Data for Name: תעסוקה מרכזי -רש"פ  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה מרכזי -רש""פ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה מרכזי -רש""פ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3928.dat';

--
-- Data for Name: תעסוקה נשים-איו"ש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-איו""ש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3929.dat';

--
-- Data for Name: תעסוקה נשים-איו"ש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-איו""ש - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3930.dat';

--
-- Data for Name: תעסוקה נשים-רצ"ע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-רצ""ע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3931.dat';

--
-- Data for Name: תעסוקה נשים-רצ"ע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-רצ""ע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3932.dat';

--
-- Data for Name: תעסוקה נשים-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3933.dat';

--
-- Data for Name: תעסוקה נשים-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נשים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה נשים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/3934.dat';

--
-- Data for Name: תעסוקה סקטורים-איו"ש-מספר ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-איו""ש-מספר " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-איו""ש-מספר " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3935.dat';

--
-- Data for Name: תעסוקה סקטורים-איו"ש-מספר  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-איו""ש-מספר  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-איו""ש-מספר  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3936.dat';

--
-- Data for Name: תעסוקה סקטורים-איו"ש-שיעור; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-איו""ש-שיעור" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-איו""ש-שיעור" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3937.dat';

--
-- Data for Name: תעסוקה סקטורים-איו"ש-שיעור - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-איו""ש-שיעור - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-איו""ש-שיעור - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3938.dat';

--
-- Data for Name: תעסוקה סקטורים-רצ"ע-מספר מ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רצ""ע-מספר מ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רצ""ע-מספר מ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3939.dat';

--
-- Data for Name: תעסוקה סקטורים-רצ"ע-מספר מ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רצ""ע-מספר מ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רצ""ע-מספר מ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3940.dat';

--
-- Data for Name: תעסוקה סקטורים-רצ"ע-שיעור ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רצ""ע-שיעור " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רצ""ע-שיעור " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3941.dat';

--
-- Data for Name: תעסוקה סקטורים-רצ"ע-שיעור  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רצ""ע-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רצ""ע-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3942.dat';

--
-- Data for Name: תעסוקה סקטורים-רש"פ-מספר מ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רש""פ-מספר מ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רש""פ-מספר מ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3943.dat';

--
-- Data for Name: תעסוקה סקטורים-רש"פ-מספר מ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רש""פ-מספר מ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רש""פ-מספר מ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/3944.dat';

--
-- Data for Name: תעסוקה סקטורים-רש"פ-שיעור ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רש""פ-שיעור " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רש""פ-שיעור " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3945.dat';

--
-- Data for Name: תעסוקה סקטורים-רש"פ-שיעור  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה סקטורים-רש""פ-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה סקטורים-רש""פ-שיעור  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3946.dat';

--
-- Data for Name: תעסוקת משכילים-רש"פ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקת משכילים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM stdin;
\.
COPY public."תעסוקת משכילים-רש""פ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM '$$PATH$$/3947.dat';

--
-- Data for Name: תעסוקת משכילים-רש"פ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקת משכילים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM stdin;
\.
COPY public."תעסוקת משכילים-רש""פ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM '$$PATH$$/3948.dat';

--
-- Data for Name: תקציב חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב חודשי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."תקציב חודשי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3949.dat';

--
-- Data for Name: תקציב חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."תקציב חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3950.dat';

--
-- Data for Name: תקציב שנתי-גרעון ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-גרעון " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-גרעון " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3951.dat';

--
-- Data for Name: תקציב שנתי-גרעון  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-גרעון  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-גרעון  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3952.dat';

--
-- Data for Name: תקציב שנתי-הוצאות ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הוצאות " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-הוצאות " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3953.dat';

--
-- Data for Name: תקציב שנתי-הוצאות  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הוצאות  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תקציב שנתי-הוצאות  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3954.dat';

--
-- Data for Name: תקציב שנתי-הכנסות; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הכנסות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-הכנסות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3955.dat';

--
-- Data for Name: תקציב שנתי-הכנסות - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-הכנסות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-הכנסות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3956.dat';

--
-- Data for Name: תקציב שנתי-סיוע חוץ ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-סיוע חוץ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-סיוע חוץ " ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3957.dat';

--
-- Data for Name: תקציב שנתי-סיוע חוץ  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תקציב שנתי-סיוע חוץ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תקציב שנתי-סיוע חוץ  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3958.dat';

--
-- PostgreSQL database dump complete
--

