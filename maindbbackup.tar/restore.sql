--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE maindb;
--
-- Name: maindb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE maindb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Israel.1252' LC_CTYPE = 'English_Israel.1252';


ALTER DATABASE maindb OWNER TO matpash;

\connect maindb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: 2019 ייצור תעשייתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."2019 ייצור תעשייתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."2019 ייצור תעשייתי" OWNER TO matpash;

--
-- Name: 2019 ייצור תעשייתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."2019 ייצור תעשייתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."2019 ייצור תעשייתי - KV" OWNER TO matpash;

--
-- Name: איוש גיל תעסוקה-אחוז האבטלה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש גיל תעסוקה-אחוז האבטלה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."איוש גיל תעסוקה-אחוז האבטלה" OWNER TO matpash;

--
-- Name: איוש גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש גיל תעסוקה-אחוז האבטלה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."איוש גיל תעסוקה-אחוז האבטלה - KV" OWNER TO matpash;

--
-- Name: איוש גיל תעסוקה-שיעור השתתפות בכוח; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש גיל תעסוקה-שיעור השתתפות בכוח" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."איוש גיל תעסוקה-שיעור השתתפות בכוח" OWNER TO matpash;

--
-- Name: איוש הכנסות שכר תעסוקה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש הכנסות שכר תעסוקה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."איוש הכנסות שכר תעסוקה" OWNER TO matpash;

--
-- Name: איוש הכנסות שכר תעסוקה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש הכנסות שכר תעסוקה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."איוש הכנסות שכר תעסוקה - KV" OWNER TO matpash;

--
-- Name: איוש נעדרים מעבודה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש נעדרים מעבודה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."איוש נעדרים מעבודה" OWNER TO matpash;

--
-- Name: איוש נעדרים מעבודה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש נעדרים מעבודה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."איוש נעדרים מעבודה - KV" OWNER TO matpash;

--
-- Name: איוש תמג לנפש רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תמג לנפש רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."איוש תמג לנפש רבעוני" OWNER TO matpash;

--
-- Name: איוש תמג לנפש רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תמג לנפש רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."איוש תמג לנפש רבעוני - KV" OWNER TO matpash;

--
-- Name: איוש תעסוקה לא בכח העבודה-מספר האנ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה לא בכח העבודה-מספר האנ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה לא בכח העבודה-מספר האנ" OWNER TO matpash;

--
-- Name: איוש תעסוקה לא בכח העבודה-שיעור מת; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה לא בכח העבודה-שיעור מת" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה לא בכח העבודה-שיעור מת" OWNER TO matpash;

--
-- Name: איוש תעסוקה מועסקים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה מועסקים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה מועסקים" OWNER TO matpash;

--
-- Name: איוש תעסוקה מועסקים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה מועסקים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה מועסקים - KV" OWNER TO matpash;

--
-- Name: איוש תעסוקה סקטור-מספר מועסקים בסק; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה סקטור-מספר מועסקים בסק" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה סקטור-מספר מועסקים בסק" OWNER TO matpash;

--
-- Name: איוש תעסוקה סקטור-שיעור מועסקים בס; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."איוש תעסוקה סקטור-שיעור מועסקים בס" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."איוש תעסוקה סקטור-שיעור מועסקים בס" OWNER TO matpash;

--
-- Name: הוצאות נתח (%) רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הוצאות נתח (%) רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."הוצאות נתח (%) רשפ שנתי" OWNER TO matpash;

--
-- Name: הוצאות נתח (%) רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הוצאות נתח (%) רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."הוצאות נתח (%) רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: הוצאות רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הוצאות רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."הוצאות רב שנתי" OWNER TO matpash;

--
-- Name: הוצאות רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הוצאות רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."הוצאות רב שנתי - KV" OWNER TO matpash;

--
-- Name: הכנסות הוצאות וגירעון רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות הוצאות וגירעון רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."הכנסות הוצאות וגירעון רב שנתי" OWNER TO matpash;

--
-- Name: הכנסות הוצאות וגירעון רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות הוצאות וגירעון רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."הכנסות הוצאות וגירעון רב שנתי - KV" OWNER TO matpash;

--
-- Name: הכנסות רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."הכנסות רב שנתי" OWNER TO matpash;

--
-- Name: הכנסות רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הכנסות רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."הכנסות רב שנתי - KV" OWNER TO matpash;

--
-- Name: העברות וקיזוזים רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."העברות וקיזוזים רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."העברות וקיזוזים רב שנתי" OWNER TO matpash;

--
-- Name: העברות וקיזוזים רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."העברות וקיזוזים רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."העברות וקיזוזים רב שנתי - KV" OWNER TO matpash;

--
-- Name: הרכב   (%) איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב   (%) איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב   (%) איוש שנתי" OWNER TO matpash;

--
-- Name: הרכב   (%) איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב   (%) איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב   (%) איוש שנתי - KV" OWNER TO matpash;

--
-- Name: הרכב (%) רצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב (%) רצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב (%) רצע שנתי" OWNER TO matpash;

--
-- Name: הרכב (%) רצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב (%) רצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב (%) רצע שנתי - KV" OWNER TO matpash;

--
-- Name: הרכב לפי סקטור (%) רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב לפי סקטור (%) רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב לפי סקטור (%) רשפ שנתי" OWNER TO matpash;

--
-- Name: הרכב לפי סקטור (%) רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."הרכב לפי סקטור (%) רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."הרכב לפי סקטור (%) רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: חברות חדשות באיוש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חברות חדשות באיוש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."חברות חדשות באיוש" OWNER TO matpash;

--
-- Name: חברות חדשות באיוש - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חברות חדשות באיוש - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."חברות חדשות באיוש - KV" OWNER TO matpash;

--
-- Name: חוב מדווח בדולר רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח בדולר רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח בדולר רב שנתי" OWNER TO matpash;

--
-- Name: חוב מדווח בדולר רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח בדולר רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח בדולר רב שנתי - KV" OWNER TO matpash;

--
-- Name: חוב מדווח בשח רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח בשח רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח בשח רב שנתי" OWNER TO matpash;

--
-- Name: חוב מדווח בשח רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב מדווח בשח רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."חוב מדווח בשח רב שנתי - KV" OWNER TO matpash;

--
-- Name: חוב ציבורי מוערך; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב ציבורי מוערך" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."חוב ציבורי מוערך" OWNER TO matpash;

--
-- Name: חוב ציבורי מוערך - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."חוב ציבורי מוערך - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."חוב ציבורי מוערך - KV" OWNER TO matpash;

--
-- Name: יחס אשראי לפיקדונות גזרות; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי לפיקדונות גזרות" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."יחס אשראי לפיקדונות גזרות" OWNER TO matpash;

--
-- Name: יחס אשראי לפיקדונות גזרות - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי לפיקדונות גזרות - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."יחס אשראי לפיקדונות גזרות - KV" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדון חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדון חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדון חודשי" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדון חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדון חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדון חודשי - KV" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדונות שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדונות שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדונות שנתי" OWNER TO matpash;

--
-- Name: יחס אשראי פיקדונות שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס אשראי פיקדונות שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."יחס אשראי פיקדונות שנתי - KV" OWNER TO matpash;

--
-- Name: יחס גירעון תוצר; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס גירעון תוצר" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."יחס גירעון תוצר" OWNER TO matpash;

--
-- Name: יחס גירעון תוצר - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס גירעון תוצר - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."יחס גירעון תוצר - KV" OWNER TO matpash;

--
-- Name: יחס חוב תוצר; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס חוב תוצר" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."יחס חוב תוצר" OWNER TO matpash;

--
-- Name: יחס חוב תוצר - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."יחס חוב תוצר - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."יחס חוב תוצר - KV" OWNER TO matpash;

--
-- Name: ייבוא; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייבוא" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."ייבוא" OWNER TO matpash;

--
-- Name: ייבוא - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייבוא - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."ייבוא - KV" OWNER TO matpash;

--
-- Name: ייבוא באלפי דולרים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייבוא באלפי דולרים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255),
    "AF1" character varying(255),
    "AG1" character varying(255),
    "AH1" character varying(255),
    "AI1" character varying(255),
    "AJ1" character varying(255),
    "AK1" character varying(255),
    "AL1" character varying(255),
    "AM1" character varying(255),
    "AN1" character varying(255),
    "AO1" character varying(255),
    "AP1" character varying(255),
    "AQ1" character varying(255),
    "AR1" character varying(255),
    "AS1" character varying(255),
    "AT1" character varying(255),
    "AU1" character varying(255),
    "AV1" character varying(255),
    "AW1" character varying(255),
    "AX1" character varying(255),
    "AY1" character varying(255),
    "AZ1" character varying(255),
    "BA1" character varying(255),
    "BB1" character varying(255),
    "BC1" character varying(255),
    "BD1" character varying(255),
    "BE1" character varying(255),
    "BF1" character varying(255),
    "BG1" character varying(255),
    "BH1" character varying(255),
    "BI1" character varying(255),
    "BJ1" character varying(255),
    "BK1" character varying(255),
    "BL1" character varying(255),
    "BM1" character varying(255),
    "BN1" character varying(255),
    "BO1" character varying(255),
    "BP1" character varying(255),
    "BQ1" character varying(255),
    "BR1" character varying(255),
    "BS1" character varying(255),
    "BT1" character varying(255),
    "BU1" character varying(255),
    "BV1" character varying(255),
    "BW1" character varying(255),
    "BX1" character varying(255),
    "BY1" character varying(255),
    "BZ1" character varying(255),
    "CA1" character varying(255),
    "CB1" character varying(255),
    "CC1" character varying(255),
    "CD1" character varying(255),
    "CE1" character varying(255),
    "CF1" character varying(255),
    "CG1" character varying(255),
    "CH1" character varying(255),
    "CI1" character varying(255),
    "CJ1" character varying(255),
    "CK1" character varying(255),
    "CL1" character varying(255),
    "CM1" character varying(255),
    "CN1" character varying(255),
    "CO1" character varying(255),
    "CP1" character varying(255),
    "CQ1" character varying(255),
    "CR1" character varying(255),
    "CS1" character varying(255),
    "CT1" character varying(255),
    "CU1" character varying(255),
    "CV1" character varying(255),
    "CW1" character varying(255),
    "CX1" character varying(255),
    "CY1" character varying(255),
    "CZ1" character varying(255),
    "DA1" character varying(255),
    "DB1" character varying(255),
    "DC1" character varying(255),
    "DD1" character varying(255),
    "DE1" character varying(255),
    "DF1" character varying(255),
    "DG1" character varying(255),
    "DH1" character varying(255),
    "DI1" character varying(255),
    "DJ1" character varying(255),
    "DK1" character varying(255),
    "DL1" character varying(255),
    "DM1" character varying(255),
    "DN1" character varying(255),
    "DO1" character varying(255),
    "DP1" character varying(255),
    "DQ1" character varying(255),
    "DR1" character varying(255),
    "DS1" character varying(255),
    "DT1" character varying(255),
    "DU1" character varying(255),
    "DV1" character varying(255),
    "DW1" character varying(255),
    "DX1" character varying(255),
    "DY1" character varying(255),
    "DZ1" character varying(255),
    "EA1" character varying(255),
    "EB1" character varying(255),
    "EC1" character varying(255),
    "ED1" character varying(255),
    "EE1" character varying(255),
    "EF1" character varying(255),
    "EG1" character varying(255),
    "EH1" character varying(255),
    "EI1" character varying(255),
    "EJ1" character varying(255),
    "EK1" character varying(255),
    "EL1" character varying(255),
    "EM1" character varying(255),
    "EN1" character varying(255),
    "EO1" character varying(255),
    "EP1" character varying(255)
);


ALTER TABLE public."ייבוא באלפי דולרים" OWNER TO matpash;

--
-- Name: ייבוא באלפי דולרים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייבוא באלפי דולרים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255),
    "AF1" character varying(255),
    "AG1" character varying(255),
    "AH1" character varying(255),
    "AI1" character varying(255),
    "AJ1" character varying(255),
    "AK1" character varying(255),
    "AL1" character varying(255),
    "AM1" character varying(255),
    "AN1" character varying(255),
    "AO1" character varying(255),
    "AP1" character varying(255),
    "AQ1" character varying(255),
    "AR1" character varying(255),
    "AS1" character varying(255),
    "AT1" character varying(255),
    "AU1" character varying(255),
    "AV1" character varying(255),
    "AW1" character varying(255),
    "AX1" character varying(255),
    "AY1" character varying(255),
    "AZ1" character varying(255),
    "BA1" character varying(255),
    "BB1" character varying(255),
    "BC1" character varying(255),
    "BD1" character varying(255),
    "BE1" character varying(255),
    "BF1" character varying(255),
    "BG1" character varying(255),
    "BH1" character varying(255),
    "BI1" character varying(255),
    "BJ1" character varying(255),
    "BK1" character varying(255),
    "BL1" character varying(255),
    "BM1" character varying(255),
    "BN1" character varying(255),
    "BO1" character varying(255),
    "BP1" character varying(255),
    "BQ1" character varying(255),
    "BR1" character varying(255),
    "BS1" character varying(255),
    "BT1" character varying(255),
    "BU1" character varying(255),
    "BV1" character varying(255),
    "BW1" character varying(255),
    "BX1" character varying(255),
    "BY1" character varying(255),
    "BZ1" character varying(255),
    "CA1" character varying(255),
    "CB1" character varying(255),
    "CC1" character varying(255),
    "CD1" character varying(255),
    "CE1" character varying(255),
    "CF1" character varying(255),
    "CG1" character varying(255),
    "CH1" character varying(255),
    "CI1" character varying(255),
    "CJ1" character varying(255),
    "CK1" character varying(255),
    "CL1" character varying(255),
    "CM1" character varying(255),
    "CN1" character varying(255),
    "CO1" character varying(255),
    "CP1" character varying(255),
    "CQ1" character varying(255),
    "CR1" character varying(255),
    "CS1" character varying(255),
    "CT1" character varying(255),
    "CU1" character varying(255),
    "CV1" character varying(255),
    "CW1" character varying(255),
    "CX1" character varying(255),
    "CY1" character varying(255),
    "CZ1" character varying(255),
    "DA1" character varying(255),
    "DB1" character varying(255),
    "DC1" character varying(255),
    "DD1" character varying(255),
    "DE1" character varying(255),
    "DF1" character varying(255),
    "DG1" character varying(255),
    "DH1" character varying(255),
    "DI1" character varying(255),
    "DJ1" character varying(255),
    "DK1" character varying(255),
    "DL1" character varying(255),
    "DM1" character varying(255),
    "DN1" character varying(255),
    "DO1" character varying(255),
    "DP1" character varying(255),
    "DQ1" character varying(255),
    "DR1" character varying(255),
    "DS1" character varying(255),
    "DT1" character varying(255),
    "DU1" character varying(255),
    "DV1" character varying(255),
    "DW1" character varying(255),
    "DX1" character varying(255),
    "DY1" character varying(255),
    "DZ1" character varying(255),
    "EA1" character varying(255),
    "EB1" character varying(255),
    "EC1" character varying(255),
    "ED1" character varying(255),
    "EE1" character varying(255),
    "EF1" character varying(255),
    "EG1" character varying(255),
    "EH1" character varying(255),
    "EI1" character varying(255),
    "EJ1" character varying(255),
    "EK1" character varying(255),
    "EL1" character varying(255),
    "EM1" character varying(255),
    "EN1" character varying(255),
    "EO1" character varying(255),
    "EP1" character varying(255)
);


ALTER TABLE public."ייבוא באלפי דולרים - KV" OWNER TO matpash;

--
-- Name: ייצוא; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצוא" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."ייצוא" OWNER TO matpash;

--
-- Name: ייצוא - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצוא - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."ייצוא - KV" OWNER TO matpash;

--
-- Name: ייצוא באלפי דולרים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצוא באלפי דולרים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255),
    "AF1" character varying(255),
    "AG1" character varying(255),
    "AH1" character varying(255),
    "AI1" character varying(255),
    "AJ1" character varying(255),
    "AK1" character varying(255),
    "AL1" character varying(255),
    "AM1" character varying(255),
    "AN1" character varying(255),
    "AO1" character varying(255),
    "AP1" character varying(255),
    "AQ1" character varying(255),
    "AR1" character varying(255),
    "AS1" character varying(255),
    "AT1" character varying(255),
    "AU1" character varying(255),
    "AV1" character varying(255),
    "AW1" character varying(255),
    "AX1" character varying(255),
    "AY1" character varying(255),
    "AZ1" character varying(255),
    "BA1" character varying(255),
    "BB1" character varying(255),
    "BC1" character varying(255),
    "BD1" character varying(255),
    "BE1" character varying(255),
    "BF1" character varying(255),
    "BG1" character varying(255),
    "BH1" character varying(255),
    "BI1" character varying(255),
    "BJ1" character varying(255),
    "BK1" character varying(255),
    "BL1" character varying(255),
    "BM1" character varying(255),
    "BN1" character varying(255),
    "BO1" character varying(255),
    "BP1" character varying(255),
    "BQ1" character varying(255),
    "BR1" character varying(255),
    "BS1" character varying(255),
    "BT1" character varying(255),
    "BU1" character varying(255),
    "BV1" character varying(255),
    "BW1" character varying(255),
    "BX1" character varying(255),
    "BY1" character varying(255),
    "BZ1" character varying(255),
    "CA1" character varying(255),
    "CB1" character varying(255),
    "CC1" character varying(255),
    "CD1" character varying(255),
    "CE1" character varying(255),
    "CF1" character varying(255),
    "CG1" character varying(255),
    "CH1" character varying(255),
    "CI1" character varying(255),
    "CJ1" character varying(255),
    "CK1" character varying(255),
    "CL1" character varying(255),
    "CM1" character varying(255),
    "CN1" character varying(255),
    "CO1" character varying(255),
    "CP1" character varying(255),
    "CQ1" character varying(255),
    "CR1" character varying(255),
    "CS1" character varying(255),
    "CT1" character varying(255),
    "CU1" character varying(255),
    "CV1" character varying(255),
    "CW1" character varying(255),
    "CX1" character varying(255),
    "CY1" character varying(255),
    "CZ1" character varying(255),
    "DA1" character varying(255),
    "DB1" character varying(255),
    "DC1" character varying(255),
    "DD1" character varying(255),
    "DE1" character varying(255),
    "DF1" character varying(255),
    "DG1" character varying(255),
    "DH1" character varying(255),
    "DI1" character varying(255),
    "DJ1" character varying(255),
    "DK1" character varying(255),
    "DL1" character varying(255),
    "DM1" character varying(255),
    "DN1" character varying(255),
    "DO1" character varying(255),
    "DP1" character varying(255),
    "DQ1" character varying(255),
    "DR1" character varying(255),
    "DS1" character varying(255),
    "DT1" character varying(255),
    "DU1" character varying(255),
    "DV1" character varying(255),
    "DW1" character varying(255),
    "DX1" character varying(255),
    "DY1" character varying(255),
    "DZ1" character varying(255),
    "EA1" character varying(255),
    "EB1" character varying(255),
    "EC1" character varying(255),
    "ED1" character varying(255),
    "EE1" character varying(255),
    "EF1" character varying(255),
    "EG1" character varying(255),
    "EH1" character varying(255),
    "EI1" character varying(255),
    "EJ1" character varying(255),
    "EK1" character varying(255),
    "EL1" character varying(255),
    "EM1" character varying(255),
    "EN1" character varying(255),
    "EO1" character varying(255)
);


ALTER TABLE public."ייצוא באלפי דולרים" OWNER TO matpash;

--
-- Name: ייצוא באלפי דולרים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצוא באלפי דולרים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255),
    "AF1" character varying(255),
    "AG1" character varying(255),
    "AH1" character varying(255),
    "AI1" character varying(255),
    "AJ1" character varying(255),
    "AK1" character varying(255),
    "AL1" character varying(255),
    "AM1" character varying(255),
    "AN1" character varying(255),
    "AO1" character varying(255),
    "AP1" character varying(255),
    "AQ1" character varying(255),
    "AR1" character varying(255),
    "AS1" character varying(255),
    "AT1" character varying(255),
    "AU1" character varying(255),
    "AV1" character varying(255),
    "AW1" character varying(255),
    "AX1" character varying(255),
    "AY1" character varying(255),
    "AZ1" character varying(255),
    "BA1" character varying(255),
    "BB1" character varying(255),
    "BC1" character varying(255),
    "BD1" character varying(255),
    "BE1" character varying(255),
    "BF1" character varying(255),
    "BG1" character varying(255),
    "BH1" character varying(255),
    "BI1" character varying(255),
    "BJ1" character varying(255),
    "BK1" character varying(255),
    "BL1" character varying(255),
    "BM1" character varying(255),
    "BN1" character varying(255),
    "BO1" character varying(255),
    "BP1" character varying(255),
    "BQ1" character varying(255),
    "BR1" character varying(255),
    "BS1" character varying(255),
    "BT1" character varying(255),
    "BU1" character varying(255),
    "BV1" character varying(255),
    "BW1" character varying(255),
    "BX1" character varying(255),
    "BY1" character varying(255),
    "BZ1" character varying(255),
    "CA1" character varying(255),
    "CB1" character varying(255),
    "CC1" character varying(255),
    "CD1" character varying(255),
    "CE1" character varying(255),
    "CF1" character varying(255),
    "CG1" character varying(255),
    "CH1" character varying(255),
    "CI1" character varying(255),
    "CJ1" character varying(255),
    "CK1" character varying(255),
    "CL1" character varying(255),
    "CM1" character varying(255),
    "CN1" character varying(255),
    "CO1" character varying(255),
    "CP1" character varying(255),
    "CQ1" character varying(255),
    "CR1" character varying(255),
    "CS1" character varying(255),
    "CT1" character varying(255),
    "CU1" character varying(255),
    "CV1" character varying(255),
    "CW1" character varying(255),
    "CX1" character varying(255),
    "CY1" character varying(255),
    "CZ1" character varying(255),
    "DA1" character varying(255),
    "DB1" character varying(255),
    "DC1" character varying(255),
    "DD1" character varying(255),
    "DE1" character varying(255),
    "DF1" character varying(255),
    "DG1" character varying(255),
    "DH1" character varying(255),
    "DI1" character varying(255),
    "DJ1" character varying(255),
    "DK1" character varying(255),
    "DL1" character varying(255),
    "DM1" character varying(255),
    "DN1" character varying(255),
    "DO1" character varying(255),
    "DP1" character varying(255),
    "DQ1" character varying(255),
    "DR1" character varying(255),
    "DS1" character varying(255),
    "DT1" character varying(255),
    "DU1" character varying(255),
    "DV1" character varying(255),
    "DW1" character varying(255),
    "DX1" character varying(255),
    "DY1" character varying(255),
    "DZ1" character varying(255),
    "EA1" character varying(255),
    "EB1" character varying(255),
    "EC1" character varying(255),
    "ED1" character varying(255),
    "EE1" character varying(255),
    "EF1" character varying(255),
    "EG1" character varying(255),
    "EH1" character varying(255),
    "EI1" character varying(255),
    "EJ1" character varying(255),
    "EK1" character varying(255),
    "EL1" character varying(255),
    "EM1" character varying(255),
    "EN1" character varying(255),
    "EO1" character varying(255)
);


ALTER TABLE public."ייצוא באלפי דולרים - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2011; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2011" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2011" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2011 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2011 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2011 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2012; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2012" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2012" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2012 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2012 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2012 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2013; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2013" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2013" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2013 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2013 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2013 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2014; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2014" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2014" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2014 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2014 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2014 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2015; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2015" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2015" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2015 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2015 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2015 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2016; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2016" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2016" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2016 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2016 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2016 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2017; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2017" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2017" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2017 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2017 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2017 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2018; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2018" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2018" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2018 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2018 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2018 - KV" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2020; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2020" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2020" OWNER TO matpash;

--
-- Name: ייצור תעשייתי 2020 - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ייצור תעשייתי 2020 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."ייצור תעשייתי 2020 - KV" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן ברצע; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן ברצע" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן ברצע" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן ברצע - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן ברצע - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן ברצע - KV" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן ברשפ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן ברשפ" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן ברשפ" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן ברשפ - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן ברשפ - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן ברשפ - KV" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן שנתי" OWNER TO matpash;

--
-- Name: מדד המחירים לצרכן שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מדד המחירים לצרכן שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."מדד המחירים לצרכן שנתי - KV" OWNER TO matpash;

--
-- Name: מחזור העסקים חודשי ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מחזור העסקים חודשי " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."מחזור העסקים חודשי " OWNER TO matpash;

--
-- Name: מחזור העסקים חודשי  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."מחזור העסקים חודשי  - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255)
);


ALTER TABLE public."מחזור העסקים חודשי  - KV" OWNER TO matpash;

--
-- Name: נתח  (%) איוש רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח  (%) איוש רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח  (%) איוש רבעוני" OWNER TO matpash;

--
-- Name: נתח  (%) איוש רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח  (%) איוש רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח  (%) איוש רבעוני - KV" OWNER TO matpash;

--
-- Name: נתח (%) עזה רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח (%) עזה רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח (%) עזה רבעוני" OWNER TO matpash;

--
-- Name: נתח (%) עזה רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח (%) עזה רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח (%) עזה רבעוני - KV" OWNER TO matpash;

--
-- Name: נתח הוצאות איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח הוצאות איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."נתח הוצאות איוש שנתי" OWNER TO matpash;

--
-- Name: נתח הוצאות איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח הוצאות איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."נתח הוצאות איוש שנתי - KV" OWNER TO matpash;

--
-- Name: נתח הסקטור (%) רשפ רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח הסקטור (%) רשפ רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח הסקטור (%) רשפ רבעוני" OWNER TO matpash;

--
-- Name: נתח הסקטור (%) רשפ רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח הסקטור (%) רשפ רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."נתח הסקטור (%) רשפ רבעוני - KV" OWNER TO matpash;

--
-- Name: נתח צד הוצאות רצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח צד הוצאות רצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."נתח צד הוצאות רצע שנתי" OWNER TO matpash;

--
-- Name: נתח צד הוצאות רצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."נתח צד הוצאות רצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255)
);


ALTER TABLE public."נתח צד הוצאות רצע שנתי - KV" OWNER TO matpash;

--
-- Name: סחר חוץ חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."סחר חוץ חודשי" OWNER TO matpash;

--
-- Name: סחר חוץ חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."סחר חוץ חודשי - KV" OWNER TO matpash;

--
-- Name: סחר חוץ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255)
);


ALTER TABLE public."סחר חוץ שנתי" OWNER TO matpash;

--
-- Name: סחר חוץ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סחר חוץ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255)
);


ALTER TABLE public."סחר חוץ שנתי - KV" OWNER TO matpash;

--
-- Name: סיוע חוץ רב שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סיוע חוץ רב שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."סיוע חוץ רב שנתי" OWNER TO matpash;

--
-- Name: סיוע חוץ רב שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."סיוע חוץ רב שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."סיוע חוץ רב שנתי - KV" OWNER TO matpash;

--
-- Name: עוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."עוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."עוני" OWNER TO matpash;

--
-- Name: עוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."עוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."עוני - KV" OWNER TO matpash;

--
-- Name: ערך התוצר איוש רבעוני ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר איוש רבעוני
" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר איוש רבעוני
" OWNER TO matpash;

--
-- Name: ערך התוצר איוש רבעוני  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר איוש רבעוני
 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר איוש רבעוני
 - KV" OWNER TO matpash;

--
-- Name: ערך התוצר איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר איוש שנתי" OWNER TO matpash;

--
-- Name: ערך התוצר איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר איוש שנתי - KV" OWNER TO matpash;

--
-- Name: ערך התוצר עזה רבעוני ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר עזה רבעוני
" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר עזה רבעוני
" OWNER TO matpash;

--
-- Name: ערך התוצר עזה רבעוני  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר עזה רבעוני
 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר עזה רבעוני
 - KV" OWNER TO matpash;

--
-- Name: ערך התוצר רצע שנתי ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רצע שנתי
" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רצע שנתי
" OWNER TO matpash;

--
-- Name: ערך התוצר רצע שנתי  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רצע שנתי
 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רצע שנתי
 - KV" OWNER TO matpash;

--
-- Name: ערך התוצר רשפ רבעוני ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רשפ רבעוני
" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רשפ רבעוני
" OWNER TO matpash;

--
-- Name: ערך התוצר רשפ רבעוני  - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רשפ רבעוני
 - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רשפ רבעוני
 - KV" OWNER TO matpash;

--
-- Name: ערך התוצר רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רשפ שנתי" OWNER TO matpash;

--
-- Name: ערך התוצר רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."ערך התוצר רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."ערך התוצר רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: צד הוצאות איוש רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות איוש רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות איוש רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות איוש רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות איוש רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות איוש רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות איוש שנתי" OWNER TO matpash;

--
-- Name: צד הוצאות איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות איוש שנתי - KV" OWNER TO matpash;

--
-- Name: צד הוצאות עזה רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות עזה רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות עזה רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות עזה רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות עזה רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות עזה רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה % רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה % רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה % רשפ שנתי" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה % רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה % רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה % רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רצע רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רצע רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רצע רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רצע רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רצע רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רצע רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רשפ רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רשפ רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רשפ רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות צמיחה (%) רשפ רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות צמיחה (%) רשפ רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות צמיחה (%) רשפ רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות רצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות רצע שנתי" OWNER TO matpash;

--
-- Name: צד הוצאות רצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות רצע שנתי - KV" OWNER TO matpash;

--
-- Name: צד הוצאות רשפ רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רשפ רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות רשפ רבעוני" OWNER TO matpash;

--
-- Name: צד הוצאות רשפ רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רשפ רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255)
);


ALTER TABLE public."צד הוצאות רשפ רבעוני - KV" OWNER TO matpash;

--
-- Name: צד הוצאות רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות רשפ שנתי" OWNER TO matpash;

--
-- Name: צד הוצאות רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צד הוצאות רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צד הוצאות רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: צמיחה  (%) איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה  (%) איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה  (%) איוש שנתי" OWNER TO matpash;

--
-- Name: צמיחה  (%) איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה  (%) איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה  (%) איוש שנתי - KV" OWNER TO matpash;

--
-- Name: צמיחה  (%) רשפ שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה  (%) רשפ שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה  (%) רשפ שנתי" OWNER TO matpash;

--
-- Name: צמיחה  (%) רשפ שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה  (%) רשפ שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה  (%) רשפ שנתי - KV" OWNER TO matpash;

--
-- Name: צמיחה % רשפ רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה % רשפ רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה % רשפ רבעוני" OWNER TO matpash;

--
-- Name: צמיחה % רשפ רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה % רשפ רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה % רשפ רבעוני - KV" OWNER TO matpash;

--
-- Name: צמיחה (%) איוש רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) איוש רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) איוש רבעוני" OWNER TO matpash;

--
-- Name: צמיחה (%) איוש רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) איוש רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) איוש רבעוני - KV" OWNER TO matpash;

--
-- Name: צמיחה (%) עזה רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) עזה רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) עזה רבעוני" OWNER TO matpash;

--
-- Name: צמיחה (%) עזה רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) עזה רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) עזה רבעוני - KV" OWNER TO matpash;

--
-- Name: צמיחה (%) רצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) רצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) רצע שנתי" OWNER TO matpash;

--
-- Name: צמיחה (%) רצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה (%) רצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."צמיחה (%) רצע שנתי - KV" OWNER TO matpash;

--
-- Name: צמיחה צד הוצאות איוש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה צד הוצאות איוש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צמיחה צד הוצאות איוש שנתי" OWNER TO matpash;

--
-- Name: צמיחה צד הוצאות איוש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה צד הוצאות איוש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צמיחה צד הוצאות איוש שנתי - KV" OWNER TO matpash;

--
-- Name: צמיחה צד הוצאות רצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה צד הוצאות רצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צמיחה צד הוצאות רצע שנתי" OWNER TO matpash;

--
-- Name: צמיחה צד הוצאות רצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צמיחה צד הוצאות רצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."צמיחה צד הוצאות רצע שנתי - KV" OWNER TO matpash;

--
-- Name: צקים חוזרים חודשי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים חודשי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים חודשי" OWNER TO matpash;

--
-- Name: צקים חוזרים חודשי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים חודשי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים חודשי - KV" OWNER TO matpash;

--
-- Name: צקים חוזרים שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים שנתי" OWNER TO matpash;

--
-- Name: צקים חוזרים שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."צקים חוזרים שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."צקים חוזרים שנתי - KV" OWNER TO matpash;

--
-- Name: רצועת עזה תמג לנפש רבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצועת עזה תמג לנפש רבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."רצועת עזה תמג לנפש רבעוני" OWNER TO matpash;

--
-- Name: רצועת עזה תמג לנפש רבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצועת עזה תמג לנפש רבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."רצועת עזה תמג לנפש רבעוני - KV" OWNER TO matpash;

--
-- Name: רצע גיל תעסוקה-אחוז האבטלה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע גיל תעסוקה-אחוז האבטלה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רצע גיל תעסוקה-אחוז האבטלה" OWNER TO matpash;

--
-- Name: רצע גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע גיל תעסוקה-אחוז האבטלה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רצע גיל תעסוקה-אחוז האבטלה - KV" OWNER TO matpash;

--
-- Name: רצע גיל תעסוקה-שיעור השתתפות בכוח ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע גיל תעסוקה-שיעור השתתפות בכוח " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רצע גיל תעסוקה-שיעור השתתפות בכוח " OWNER TO matpash;

--
-- Name: רצע הכנסות שכר תעסוקה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע הכנסות שכר תעסוקה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רצע הכנסות שכר תעסוקה" OWNER TO matpash;

--
-- Name: רצע הכנסות שכר תעסוקה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע הכנסות שכר תעסוקה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רצע הכנסות שכר תעסוקה - KV" OWNER TO matpash;

--
-- Name: רצע נעדרים מעבודה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע נעדרים מעבודה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רצע נעדרים מעבודה" OWNER TO matpash;

--
-- Name: רצע נעדרים מעבודה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע נעדרים מעבודה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רצע נעדרים מעבודה - KV" OWNER TO matpash;

--
-- Name: רצע תעסוקה לא בכח העבודה-מספר האנש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה לא בכח העבודה-מספר האנש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה לא בכח העבודה-מספר האנש" OWNER TO matpash;

--
-- Name: רצע תעסוקה לא בכח העבודה-שיעור מתו; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה לא בכח העבודה-שיעור מתו" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה לא בכח העבודה-שיעור מתו" OWNER TO matpash;

--
-- Name: רצע תעסוקה מועסקים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה מועסקים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה מועסקים" OWNER TO matpash;

--
-- Name: רצע תעסוקה מועסקים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה מועסקים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה מועסקים - KV" OWNER TO matpash;

--
-- Name: רצע תעסוקה סקטור-מספר מועסקים בסקט; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה סקטור-מספר מועסקים בסקט" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה סקטור-מספר מועסקים בסקט" OWNER TO matpash;

--
-- Name: רצע תעסוקה סקטור-שיעור מועסקים בסק; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רצע תעסוקה סקטור-שיעור מועסקים בסק" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."רצע תעסוקה סקטור-שיעור מועסקים בסק" OWNER TO matpash;

--
-- Name: רשפ בעלי תעודה אקדמית תעסוקה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ בעלי תעודה אקדמית תעסוקה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255)
);


ALTER TABLE public."רשפ בעלי תעודה אקדמית תעסוקה" OWNER TO matpash;

--
-- Name: רשפ בעלי תעודה אקדמית תעסוקה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ בעלי תעודה אקדמית תעסוקה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255),
    "V1" character varying(255),
    "W1" character varying(255),
    "X1" character varying(255),
    "Y1" character varying(255),
    "Z1" character varying(255),
    "AA1" character varying(255),
    "AB1" character varying(255),
    "AC1" character varying(255),
    "AD1" character varying(255),
    "AE1" character varying(255)
);


ALTER TABLE public."רשפ בעלי תעודה אקדמית תעסוקה - KV" OWNER TO matpash;

--
-- Name: רשפ גיל תעסוקה-אחוז האבטלה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ גיל תעסוקה-אחוז האבטלה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רשפ גיל תעסוקה-אחוז האבטלה" OWNER TO matpash;

--
-- Name: רשפ גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ גיל תעסוקה-אחוז האבטלה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רשפ גיל תעסוקה-אחוז האבטלה - KV" OWNER TO matpash;

--
-- Name: רשפ גיל תעסוקה-שיעור השתתפות בכוח ; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ גיל תעסוקה-שיעור השתתפות בכוח " (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255)
);


ALTER TABLE public."רשפ גיל תעסוקה-שיעור השתתפות בכוח " OWNER TO matpash;

--
-- Name: רשפ הכנסות שכר תעסוקה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ הכנסות שכר תעסוקה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."רשפ הכנסות שכר תעסוקה" OWNER TO matpash;

--
-- Name: רשפ הכנסות שכר תעסוקה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ הכנסות שכר תעסוקה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."רשפ הכנסות שכר תעסוקה - KV" OWNER TO matpash;

--
-- Name: רשפ נעדרים מעבודה; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ נעדרים מעבודה" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רשפ נעדרים מעבודה" OWNER TO matpash;

--
-- Name: רשפ נעדרים מעבודה - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ נעדרים מעבודה - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."רשפ נעדרים מעבודה - KV" OWNER TO matpash;

--
-- Name: רשפ תמג לנפשרבעוני; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תמג לנפשרבעוני" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."רשפ תמג לנפשרבעוני" OWNER TO matpash;

--
-- Name: רשפ תמג לנפשרבעוני - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תמג לנפשרבעוני - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255)
);


ALTER TABLE public."רשפ תמג לנפשרבעוני - KV" OWNER TO matpash;

--
-- Name: רשפ תעסוקה לא בכח העבודה-מספר האנש; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה לא בכח העבודה-מספר האנש" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה לא בכח העבודה-מספר האנש" OWNER TO matpash;

--
-- Name: רשפ תעסוקה לא בכח העבודה-שיעור מתו; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה לא בכח העבודה-שיעור מתו" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה לא בכח העבודה-שיעור מתו" OWNER TO matpash;

--
-- Name: רשפ תעסוקה מועסקים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה מועסקים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה מועסקים" OWNER TO matpash;

--
-- Name: רשפ תעסוקה מועסקים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה מועסקים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה מועסקים - KV" OWNER TO matpash;

--
-- Name: רשפ תעסוקה סקטור-מספר מועסקים בסקט; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה סקטור-מספר מועסקים בסקט" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה סקטור-מספר מועסקים בסקט" OWNER TO matpash;

--
-- Name: רשפ תעסוקה סקטור-שיעור מועסקים בסק; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."רשפ תעסוקה סקטור-שיעור מועסקים בסק" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."רשפ תעסוקה סקטור-שיעור מועסקים בסק" OWNER TO matpash;

--
-- Name: שינוי ביחס לרבעון הקודם תמג לנפש ר; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שינוי ביחס לרבעון הקודם תמג לנפש ר" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255)
);


ALTER TABLE public."שינוי ביחס לרבעון הקודם תמג לנפש ר" OWNER TO matpash;

--
-- Name: שינוי במחיירם ברצע ביחס לחודש הקוד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שינוי במחיירם ברצע ביחס לחודש הקוד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."שינוי במחיירם ברצע ביחס לחודש הקוד" OWNER TO matpash;

--
-- Name: שינוי במחירים ברצע ביחס לאשתקד; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שינוי במחירים ברצע ביחס לאשתקד" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."שינוי במחירים ברצע ביחס לאשתקד" OWNER TO matpash;

--
-- Name: שינוי במחירים ברצע ביחס לאשתקד - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שינוי במחירים ברצע ביחס לאשתקד - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255)
);


ALTER TABLE public."שינוי במחירים ברצע ביחס לאשתקד - KV" OWNER TO matpash;

--
-- Name: שינוי במחירים ברשפ ביחס לחודש המקב; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שינוי במחירים ברשפ ביחס לחודש המקב" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255)
);


ALTER TABLE public."שינוי במחירים ברשפ ביחס לחודש המקב" OWNER TO matpash;

--
-- Name: שכר יומי ממוצע שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שכר יומי ממוצע שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255)
);


ALTER TABLE public."שכר יומי ממוצע שנתי" OWNER TO matpash;

--
-- Name: שכר יומי ממוצע שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שכר יומי ממוצע שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255),
    "T1" character varying(255),
    "U1" character varying(255)
);


ALTER TABLE public."שכר יומי ממוצע שנתי - KV" OWNER TO matpash;

--
-- Name: שנתי ייצור תעשייתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שנתי ייצור תעשייתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255)
);


ALTER TABLE public."שנתי ייצור תעשייתי" OWNER TO matpash;

--
-- Name: שנתי ייצור תעשייתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."שנתי ייצור תעשייתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255)
);


ALTER TABLE public."שנתי ייצור תעשייתי - KV" OWNER TO matpash;

--
-- Name: תוצר לנפש שנתי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש שנתי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תוצר לנפש שנתי" OWNER TO matpash;

--
-- Name: תוצר לנפש שנתי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תוצר לנפש שנתי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תוצר לנפש שנתי - KV" OWNER TO matpash;

--
-- Name: תעסוקה איוש גברים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש גברים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש גברים" OWNER TO matpash;

--
-- Name: תעסוקה איוש גברים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש גברים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש גברים - KV" OWNER TO matpash;

--
-- Name: תעסוקה איוש מרכזי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש מרכזי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש מרכזי" OWNER TO matpash;

--
-- Name: תעסוקה איוש מרכזי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש מרכזי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש מרכזי - KV" OWNER TO matpash;

--
-- Name: תעסוקה איוש נשים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש נשים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש נשים" OWNER TO matpash;

--
-- Name: תעסוקה איוש נשים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה איוש נשים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה איוש נשים - KV" OWNER TO matpash;

--
-- Name: תעסוקה בישראל; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה בישראל" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תעסוקה בישראל" OWNER TO matpash;

--
-- Name: תעסוקה בישראל - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה בישראל - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255)
);


ALTER TABLE public."תעסוקה בישראל - KV" OWNER TO matpash;

--
-- Name: תעסוקה ישראל והתיישבות מרכזי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה ישראל והתיישבות מרכזי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה ישראל והתיישבות מרכזי" OWNER TO matpash;

--
-- Name: תעסוקה ישראל והתיישבות מרכזי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה ישראל והתיישבות מרכזי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255)
);


ALTER TABLE public."תעסוקה ישראל והתיישבות מרכזי - KV" OWNER TO matpash;

--
-- Name: תעסוקה נתונים שנתיים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נתונים שנתיים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."תעסוקה נתונים שנתיים" OWNER TO matpash;

--
-- Name: תעסוקה נתונים שנתיים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה נתונים שנתיים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255),
    "M1" character varying(255),
    "N1" character varying(255),
    "O1" character varying(255),
    "P1" character varying(255),
    "Q1" character varying(255),
    "R1" character varying(255),
    "S1" character varying(255)
);


ALTER TABLE public."תעסוקה נתונים שנתיים - KV" OWNER TO matpash;

--
-- Name: תעסוקה רצע גברים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע גברים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע גברים" OWNER TO matpash;

--
-- Name: תעסוקה רצע גברים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע גברים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע גברים - KV" OWNER TO matpash;

--
-- Name: תעסוקה רצע מרכזי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע מרכזי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע מרכזי" OWNER TO matpash;

--
-- Name: תעסוקה רצע מרכזי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע מרכזי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע מרכזי - KV" OWNER TO matpash;

--
-- Name: תעסוקה רצע נשים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע נשים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע נשים" OWNER TO matpash;

--
-- Name: תעסוקה רצע נשים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רצע נשים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רצע נשים - KV" OWNER TO matpash;

--
-- Name: תעסוקה רשפ גברים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ גברים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ גברים" OWNER TO matpash;

--
-- Name: תעסוקה רשפ גברים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ גברים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ גברים - KV" OWNER TO matpash;

--
-- Name: תעסוקה רשפ מרכזי; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ מרכזי" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ מרכזי" OWNER TO matpash;

--
-- Name: תעסוקה רשפ מרכזי - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ מרכזי - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ מרכזי - KV" OWNER TO matpash;

--
-- Name: תעסוקה רשפ נשים; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ נשים" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ נשים" OWNER TO matpash;

--
-- Name: תעסוקה רשפ נשים - KV; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."תעסוקה רשפ נשים - KV" (
    "A1" character varying(255),
    "B1" character varying(255),
    "C1" character varying(255),
    "D1" character varying(255),
    "E1" character varying(255),
    "F1" character varying(255),
    "G1" character varying(255),
    "H1" character varying(255),
    "I1" character varying(255),
    "J1" character varying(255),
    "K1" character varying(255),
    "L1" character varying(255)
);


ALTER TABLE public."תעסוקה רשפ נשים - KV" OWNER TO matpash;

--
-- Data for Name: 2019 ייצור תעשייתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."2019 ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."2019 ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4061.dat';

--
-- Data for Name: 2019 ייצור תעשייתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."2019 ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."2019 ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4062.dat';

--
-- Data for Name: איוש גיל תעסוקה-אחוז האבטלה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."איוש גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4017.dat';

--
-- Data for Name: איוש גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."איוש גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4018.dat';

--
-- Data for Name: איוש גיל תעסוקה-שיעור השתתפות בכוח; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש גיל תעסוקה-שיעור השתתפות בכוח" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."איוש גיל תעסוקה-שיעור השתתפות בכוח" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4016.dat';

--
-- Data for Name: איוש הכנסות שכר תעסוקה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."איוש הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4023.dat';

--
-- Data for Name: איוש הכנסות שכר תעסוקה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."איוש הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4024.dat';

--
-- Data for Name: איוש נעדרים מעבודה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."איוש נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3951.dat';

--
-- Data for Name: איוש נעדרים מעבודה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."איוש נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3952.dat';

--
-- Data for Name: איוש תמג לנפש רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תמג לנפש רבעוני" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."איוש תמג לנפש רבעוני" ("A1", "B1", "C1") FROM '$$PATH$$/3995.dat';

--
-- Data for Name: איוש תמג לנפש רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תמג לנפש רבעוני - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."איוש תמג לנפש רבעוני - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3996.dat';

--
-- Data for Name: איוש תעסוקה לא בכח העבודה-מספר האנ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה לא בכח העבודה-מספר האנ" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."איוש תעסוקה לא בכח העבודה-מספר האנ" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4034.dat';

--
-- Data for Name: איוש תעסוקה לא בכח העבודה-שיעור מת; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה לא בכח העבודה-שיעור מת" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."איוש תעסוקה לא בכח העבודה-שיעור מת" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/4033.dat';

--
-- Data for Name: איוש תעסוקה מועסקים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."איוש תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4029.dat';

--
-- Data for Name: איוש תעסוקה מועסקים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."איוש תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4030.dat';

--
-- Data for Name: איוש תעסוקה סקטור-מספר מועסקים בסק; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה סקטור-מספר מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."איוש תעסוקה סקטור-מספר מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/4056.dat';

--
-- Data for Name: איוש תעסוקה סקטור-שיעור מועסקים בס; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."איוש תעסוקה סקטור-שיעור מועסקים בס" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."איוש תעסוקה סקטור-שיעור מועסקים בס" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4055.dat';

--
-- Data for Name: הוצאות נתח (%) רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הוצאות נתח (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."הוצאות נתח (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4129.dat';

--
-- Data for Name: הוצאות נתח (%) רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הוצאות נתח (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."הוצאות נתח (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4130.dat';

--
-- Data for Name: הוצאות רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הוצאות רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."הוצאות רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3957.dat';

--
-- Data for Name: הוצאות רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הוצאות רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."הוצאות רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3958.dat';

--
-- Data for Name: הכנסות הוצאות וגירעון רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות הוצאות וגירעון רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."הכנסות הוצאות וגירעון רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3961.dat';

--
-- Data for Name: הכנסות הוצאות וגירעון רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות הוצאות וגירעון רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."הכנסות הוצאות וגירעון רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3962.dat';

--
-- Data for Name: הכנסות רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."הכנסות רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3955.dat';

--
-- Data for Name: הכנסות רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הכנסות רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."הכנסות רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3956.dat';

--
-- Data for Name: העברות וקיזוזים רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."העברות וקיזוזים רב שנתי" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."העברות וקיזוזים רב שנתי" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/4063.dat';

--
-- Data for Name: העברות וקיזוזים רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."העברות וקיזוזים רב שנתי - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."העברות וקיזוזים רב שנתי - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/4064.dat';

--
-- Data for Name: הרכב   (%) איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב   (%) איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב   (%) איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4079.dat';

--
-- Data for Name: הרכב   (%) איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב   (%) איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב   (%) איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4080.dat';

--
-- Data for Name: הרכב (%) רצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב (%) רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב (%) רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4101.dat';

--
-- Data for Name: הרכב (%) רצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב (%) רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב (%) רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4102.dat';

--
-- Data for Name: הרכב לפי סקטור (%) רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב לפי סקטור (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב לפי סקטור (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4123.dat';

--
-- Data for Name: הרכב לפי סקטור (%) רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."הרכב לפי סקטור (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."הרכב לפי סקטור (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4124.dat';

--
-- Data for Name: חברות חדשות באיוש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חברות חדשות באיוש" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."חברות חדשות באיוש" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/4131.dat';

--
-- Data for Name: חברות חדשות באיוש - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חברות חדשות באיוש - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."חברות חדשות באיוש - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/4132.dat';

--
-- Data for Name: חוב מדווח בדולר רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח בדולר רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח בדולר רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4135.dat';

--
-- Data for Name: חוב מדווח בדולר רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח בדולר רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח בדולר רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4136.dat';

--
-- Data for Name: חוב מדווח בשח רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח בשח רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח בשח רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4133.dat';

--
-- Data for Name: חוב מדווח בשח רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב מדווח בשח רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."חוב מדווח בשח רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4134.dat';

--
-- Data for Name: חוב ציבורי מוערך; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב ציבורי מוערך" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."חוב ציבורי מוערך" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/4137.dat';

--
-- Data for Name: חוב ציבורי מוערך - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."חוב ציבורי מוערך - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."חוב ציבורי מוערך - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/4138.dat';

--
-- Data for Name: יחס אשראי לפיקדונות גזרות; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי לפיקדונות גזרות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."יחס אשראי לפיקדונות גזרות" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/3917.dat';

--
-- Data for Name: יחס אשראי לפיקדונות גזרות - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי לפיקדונות גזרות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."יחס אשראי לפיקדונות גזרות - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/3918.dat';

--
-- Data for Name: יחס אשראי פיקדון חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדון חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדון חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3919.dat';

--
-- Data for Name: יחס אשראי פיקדון חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדון חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדון חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3920.dat';

--
-- Data for Name: יחס אשראי פיקדונות שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדונות שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדונות שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3921.dat';

--
-- Data for Name: יחס אשראי פיקדונות שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס אשראי פיקדונות שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."יחס אשראי פיקדונות שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/3922.dat';

--
-- Data for Name: יחס גירעון תוצר; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס גירעון תוצר" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."יחס גירעון תוצר" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3923.dat';

--
-- Data for Name: יחס גירעון תוצר - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס גירעון תוצר - KV" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."יחס גירעון תוצר - KV" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/3924.dat';

--
-- Data for Name: יחס חוב תוצר; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס חוב תוצר" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."יחס חוב תוצר" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3925.dat';

--
-- Data for Name: יחס חוב תוצר - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."יחס חוב תוצר - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."יחס חוב תוצר - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3926.dat';

--
-- Data for Name: ייבוא; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייבוא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."ייבוא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3967.dat';

--
-- Data for Name: ייבוא - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייבוא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."ייבוא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3968.dat';

--
-- Data for Name: ייבוא באלפי דולרים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייבוא באלפי דולרים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1", "EP1") FROM stdin;
\.
COPY public."ייבוא באלפי דולרים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1", "EP1") FROM '$$PATH$$/3971.dat';

--
-- Data for Name: ייבוא באלפי דולרים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייבוא באלפי דולרים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1", "EP1") FROM stdin;
\.
COPY public."ייבוא באלפי דולרים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1", "EP1") FROM '$$PATH$$/3972.dat';

--
-- Data for Name: ייצוא; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצוא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."ייצוא" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3969.dat';

--
-- Data for Name: ייצוא - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצוא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."ייצוא - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3970.dat';

--
-- Data for Name: ייצוא באלפי דולרים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצוא באלפי דולרים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1") FROM stdin;
\.
COPY public."ייצוא באלפי דולרים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1") FROM '$$PATH$$/3973.dat';

--
-- Data for Name: ייצוא באלפי דולרים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצוא באלפי דולרים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1") FROM stdin;
\.
COPY public."ייצוא באלפי דולרים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1", "AF1", "AG1", "AH1", "AI1", "AJ1", "AK1", "AL1", "AM1", "AN1", "AO1", "AP1", "AQ1", "AR1", "AS1", "AT1", "AU1", "AV1", "AW1", "AX1", "AY1", "AZ1", "BA1", "BB1", "BC1", "BD1", "BE1", "BF1", "BG1", "BH1", "BI1", "BJ1", "BK1", "BL1", "BM1", "BN1", "BO1", "BP1", "BQ1", "BR1", "BS1", "BT1", "BU1", "BV1", "BW1", "BX1", "BY1", "BZ1", "CA1", "CB1", "CC1", "CD1", "CE1", "CF1", "CG1", "CH1", "CI1", "CJ1", "CK1", "CL1", "CM1", "CN1", "CO1", "CP1", "CQ1", "CR1", "CS1", "CT1", "CU1", "CV1", "CW1", "CX1", "CY1", "CZ1", "DA1", "DB1", "DC1", "DD1", "DE1", "DF1", "DG1", "DH1", "DI1", "DJ1", "DK1", "DL1", "DM1", "DN1", "DO1", "DP1", "DQ1", "DR1", "DS1", "DT1", "DU1", "DV1", "DW1", "DX1", "DY1", "DZ1", "EA1", "EB1", "EC1", "ED1", "EE1", "EF1", "EG1", "EH1", "EI1", "EJ1", "EK1", "EL1", "EM1", "EN1", "EO1") FROM '$$PATH$$/3974.dat';

--
-- Data for Name: ייצור תעשייתי 2011; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2011" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2011" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3927.dat';

--
-- Data for Name: ייצור תעשייתי 2011 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2011 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2011 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3928.dat';

--
-- Data for Name: ייצור תעשייתי 2012; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2012" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2012" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3929.dat';

--
-- Data for Name: ייצור תעשייתי 2012 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2012 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2012 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3930.dat';

--
-- Data for Name: ייצור תעשייתי 2013; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2013" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2013" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3931.dat';

--
-- Data for Name: ייצור תעשייתי 2013 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2013 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2013 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3932.dat';

--
-- Data for Name: ייצור תעשייתי 2014; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2014" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2014" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3933.dat';

--
-- Data for Name: ייצור תעשייתי 2014 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2014 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2014 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3934.dat';

--
-- Data for Name: ייצור תעשייתי 2015; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2015" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2015" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3935.dat';

--
-- Data for Name: ייצור תעשייתי 2015 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2015 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2015 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3936.dat';

--
-- Data for Name: ייצור תעשייתי 2016; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2016" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2016" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3937.dat';

--
-- Data for Name: ייצור תעשייתי 2016 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2016 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2016 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3938.dat';

--
-- Data for Name: ייצור תעשייתי 2017; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2017" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2017" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3939.dat';

--
-- Data for Name: ייצור תעשייתי 2017 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2017 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2017 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3940.dat';

--
-- Data for Name: ייצור תעשייתי 2018; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2018" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2018" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3941.dat';

--
-- Data for Name: ייצור תעשייתי 2018 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2018 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2018 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3942.dat';

--
-- Data for Name: ייצור תעשייתי 2020; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2020" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2020" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3943.dat';

--
-- Data for Name: ייצור תעשייתי 2020 - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ייצור תעשייתי 2020 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."ייצור תעשייתי 2020 - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/3944.dat';

--
-- Data for Name: מדד המחירים לצרכן ברצע; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן ברצע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן ברצע" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3981.dat';

--
-- Data for Name: מדד המחירים לצרכן ברצע - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן ברצע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן ברצע - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3982.dat';

--
-- Data for Name: מדד המחירים לצרכן ברשפ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן ברשפ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן ברשפ" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3986.dat';

--
-- Data for Name: מדד המחירים לצרכן ברשפ - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן ברשפ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן ברשפ - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3987.dat';

--
-- Data for Name: מדד המחירים לצרכן שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3945.dat';

--
-- Data for Name: מדד המחירים לצרכן שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מדד המחירים לצרכן שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."מדד המחירים לצרכן שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3946.dat';

--
-- Data for Name: מחזור העסקים חודשי ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מחזור העסקים חודשי " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."מחזור העסקים חודשי " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3947.dat';

--
-- Data for Name: מחזור העסקים חודשי  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."מחזור העסקים חודשי  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM stdin;
\.
COPY public."מחזור העסקים חודשי  - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1") FROM '$$PATH$$/3948.dat';

--
-- Data for Name: נתח  (%) איוש רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח  (%) איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח  (%) איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4069.dat';

--
-- Data for Name: נתח  (%) איוש רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח  (%) איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח  (%) איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4070.dat';

--
-- Data for Name: נתח (%) עזה רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח (%) עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח (%) עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4091.dat';

--
-- Data for Name: נתח (%) עזה רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח (%) עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח (%) עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4092.dat';

--
-- Data for Name: נתח הוצאות איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."נתח הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4085.dat';

--
-- Data for Name: נתח הוצאות איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."נתח הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4086.dat';

--
-- Data for Name: נתח הסקטור (%) רשפ רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח הסקטור (%) רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח הסקטור (%) רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4113.dat';

--
-- Data for Name: נתח הסקטור (%) רשפ רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח הסקטור (%) רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."נתח הסקטור (%) רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4114.dat';

--
-- Data for Name: נתח צד הוצאות רצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."נתח צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4107.dat';

--
-- Data for Name: נתח צד הוצאות רצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."נתח צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM stdin;
\.
COPY public."נתח צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1") FROM '$$PATH$$/4108.dat';

--
-- Data for Name: סחר חוץ חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."סחר חוץ חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3963.dat';

--
-- Data for Name: סחר חוץ חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."סחר חוץ חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/3964.dat';

--
-- Data for Name: סחר חוץ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1") FROM stdin;
\.
COPY public."סחר חוץ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1") FROM '$$PATH$$/3965.dat';

--
-- Data for Name: סחר חוץ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סחר חוץ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1") FROM stdin;
\.
COPY public."סחר חוץ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1") FROM '$$PATH$$/3966.dat';

--
-- Data for Name: סיוע חוץ רב שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סיוע חוץ רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."סיוע חוץ רב שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3959.dat';

--
-- Data for Name: סיוע חוץ רב שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."סיוע חוץ רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."סיוע חוץ רב שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3960.dat';

--
-- Data for Name: עוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."עוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."עוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3975.dat';

--
-- Data for Name: עוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."עוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."עוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3976.dat';

--
-- Data for Name: ערך התוצר איוש רבעוני ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר איוש רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר איוש רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4065.dat';

--
-- Data for Name: ערך התוצר איוש רבעוני  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר איוש רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר איוש רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4066.dat';

--
-- Data for Name: ערך התוצר איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4075.dat';

--
-- Data for Name: ערך התוצר איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4076.dat';

--
-- Data for Name: ערך התוצר עזה רבעוני ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר עזה רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר עזה רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4087.dat';

--
-- Data for Name: ערך התוצר עזה רבעוני  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר עזה רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר עזה רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4088.dat';

--
-- Data for Name: ערך התוצר רצע שנתי ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רצע שנתי
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רצע שנתי
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4097.dat';

--
-- Data for Name: ערך התוצר רצע שנתי  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רצע שנתי
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רצע שנתי
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4098.dat';

--
-- Data for Name: ערך התוצר רשפ רבעוני ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רשפ רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רשפ רבעוני
" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4109.dat';

--
-- Data for Name: ערך התוצר רשפ רבעוני  - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רשפ רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רשפ רבעוני
 - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4110.dat';

--
-- Data for Name: ערך התוצר רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4119.dat';

--
-- Data for Name: ערך התוצר רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."ערך התוצר רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."ערך התוצר רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4120.dat';

--
-- Data for Name: צד הוצאות איוש רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4071.dat';

--
-- Data for Name: צד הוצאות איוש רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4072.dat';

--
-- Data for Name: צד הוצאות איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4081.dat';

--
-- Data for Name: צד הוצאות איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4082.dat';

--
-- Data for Name: צד הוצאות עזה רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4093.dat';

--
-- Data for Name: צד הוצאות עזה רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4094.dat';

--
-- Data for Name: צד הוצאות צמיחה % רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה % רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה % רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4127.dat';

--
-- Data for Name: צד הוצאות צמיחה % רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה % רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה % רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4128.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4073.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4074.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רצע רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רצע רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רצע רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4095.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רצע רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רצע רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רצע רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4096.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רשפ רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4117.dat';

--
-- Data for Name: צד הוצאות צמיחה (%) רשפ רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות צמיחה (%) רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות צמיחה (%) רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4118.dat';

--
-- Data for Name: צד הוצאות רצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4103.dat';

--
-- Data for Name: צד הוצאות רצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4104.dat';

--
-- Data for Name: צד הוצאות רשפ רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4115.dat';

--
-- Data for Name: צד הוצאות רשפ רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM stdin;
\.
COPY public."צד הוצאות רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1") FROM '$$PATH$$/4116.dat';

--
-- Data for Name: צד הוצאות רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4125.dat';

--
-- Data for Name: צד הוצאות רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צד הוצאות רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צד הוצאות רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4126.dat';

--
-- Data for Name: צמיחה  (%) איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה  (%) איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה  (%) איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4077.dat';

--
-- Data for Name: צמיחה  (%) איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה  (%) איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה  (%) איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4078.dat';

--
-- Data for Name: צמיחה  (%) רשפ שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה  (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה  (%) רשפ שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4121.dat';

--
-- Data for Name: צמיחה  (%) רשפ שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה  (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה  (%) רשפ שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4122.dat';

--
-- Data for Name: צמיחה % רשפ רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה % רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה % רשפ רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4111.dat';

--
-- Data for Name: צמיחה % רשפ רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה % רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה % רשפ רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4112.dat';

--
-- Data for Name: צמיחה (%) איוש רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) איוש רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4067.dat';

--
-- Data for Name: צמיחה (%) איוש רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) איוש רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4068.dat';

--
-- Data for Name: צמיחה (%) עזה רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) עזה רבעוני" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4089.dat';

--
-- Data for Name: צמיחה (%) עזה רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) עזה רבעוני - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4090.dat';

--
-- Data for Name: צמיחה (%) רצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4099.dat';

--
-- Data for Name: צמיחה (%) רצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה (%) רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."צמיחה (%) רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4100.dat';

--
-- Data for Name: צמיחה צד הוצאות איוש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה צד הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צמיחה צד הוצאות איוש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4083.dat';

--
-- Data for Name: צמיחה צד הוצאות איוש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה צד הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צמיחה צד הוצאות איוש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4084.dat';

--
-- Data for Name: צמיחה צד הוצאות רצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צמיחה צד הוצאות רצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4105.dat';

--
-- Data for Name: צמיחה צד הוצאות רצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צמיחה צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."צמיחה צד הוצאות רצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4106.dat';

--
-- Data for Name: צקים חוזרים חודשי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים חודשי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3977.dat';

--
-- Data for Name: צקים חוזרים חודשי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים חודשי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3978.dat';

--
-- Data for Name: צקים חוזרים שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3979.dat';

--
-- Data for Name: צקים חוזרים שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."צקים חוזרים שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."צקים חוזרים שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/3980.dat';

--
-- Data for Name: רצועת עזה תמג לנפש רבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצועת עזה תמג לנפש רבעוני" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."רצועת עזה תמג לנפש רבעוני" ("A1", "B1", "C1") FROM '$$PATH$$/3997.dat';

--
-- Data for Name: רצועת עזה תמג לנפש רבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצועת עזה תמג לנפש רבעוני - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."רצועת עזה תמג לנפש רבעוני - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3998.dat';

--
-- Data for Name: רצע גיל תעסוקה-אחוז האבטלה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רצע גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4014.dat';

--
-- Data for Name: רצע גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רצע גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4015.dat';

--
-- Data for Name: רצע גיל תעסוקה-שיעור השתתפות בכוח ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע גיל תעסוקה-שיעור השתתפות בכוח " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רצע גיל תעסוקה-שיעור השתתפות בכוח " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4013.dat';

--
-- Data for Name: רצע הכנסות שכר תעסוקה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רצע הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/4021.dat';

--
-- Data for Name: רצע הכנסות שכר תעסוקה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רצע הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/4022.dat';

--
-- Data for Name: רצע נעדרים מעבודה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רצע נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3953.dat';

--
-- Data for Name: רצע נעדרים מעבודה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רצע נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3954.dat';

--
-- Data for Name: רצע תעסוקה לא בכח העבודה-מספר האנש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה לא בכח העבודה-מספר האנש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM stdin;
\.
COPY public."רצע תעסוקה לא בכח העבודה-מספר האנש" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1") FROM '$$PATH$$/4036.dat';

--
-- Data for Name: רצע תעסוקה לא בכח העבודה-שיעור מתו; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה לא בכח העבודה-שיעור מתו" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."רצע תעסוקה לא בכח העבודה-שיעור מתו" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/4035.dat';

--
-- Data for Name: רצע תעסוקה מועסקים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM stdin;
\.
COPY public."רצע תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM '$$PATH$$/4027.dat';

--
-- Data for Name: רצע תעסוקה מועסקים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM stdin;
\.
COPY public."רצע תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1") FROM '$$PATH$$/4028.dat';

--
-- Data for Name: רצע תעסוקה סקטור-מספר מועסקים בסקט; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה סקטור-מספר מועסקים בסקט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."רצע תעסוקה סקטור-מספר מועסקים בסקט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/4058.dat';

--
-- Data for Name: רצע תעסוקה סקטור-שיעור מועסקים בסק; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רצע תעסוקה סקטור-שיעור מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."רצע תעסוקה סקטור-שיעור מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4057.dat';

--
-- Data for Name: רשפ בעלי תעודה אקדמית תעסוקה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ בעלי תעודה אקדמית תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM stdin;
\.
COPY public."רשפ בעלי תעודה אקדמית תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM '$$PATH$$/4059.dat';

--
-- Data for Name: רשפ בעלי תעודה אקדמית תעסוקה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ בעלי תעודה אקדמית תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM stdin;
\.
COPY public."רשפ בעלי תעודה אקדמית תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1", "V1", "W1", "X1", "Y1", "Z1", "AA1", "AB1", "AC1", "AD1", "AE1") FROM '$$PATH$$/4060.dat';

--
-- Data for Name: רשפ גיל תעסוקה-אחוז האבטלה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רשפ גיל תעסוקה-אחוז האבטלה" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4011.dat';

--
-- Data for Name: רשפ גיל תעסוקה-אחוז האבטלה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רשפ גיל תעסוקה-אחוז האבטלה - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4012.dat';

--
-- Data for Name: רשפ גיל תעסוקה-שיעור השתתפות בכוח ; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ גיל תעסוקה-שיעור השתתפות בכוח " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM stdin;
\.
COPY public."רשפ גיל תעסוקה-שיעור השתתפות בכוח " ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1") FROM '$$PATH$$/4010.dat';

--
-- Data for Name: רשפ הכנסות שכר תעסוקה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."רשפ הכנסות שכר תעסוקה" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4019.dat';

--
-- Data for Name: רשפ הכנסות שכר תעסוקה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."רשפ הכנסות שכר תעסוקה - KV" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4020.dat';

--
-- Data for Name: רשפ נעדרים מעבודה; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רשפ נעדרים מעבודה" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3949.dat';

--
-- Data for Name: רשפ נעדרים מעבודה - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."רשפ נעדרים מעבודה - KV" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3950.dat';

--
-- Data for Name: רשפ תמג לנפשרבעוני; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תמג לנפשרבעוני" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."רשפ תמג לנפשרבעוני" ("A1", "B1", "C1") FROM '$$PATH$$/3993.dat';

--
-- Data for Name: רשפ תמג לנפשרבעוני - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תמג לנפשרבעוני - KV" ("A1", "B1", "C1") FROM stdin;
\.
COPY public."רשפ תמג לנפשרבעוני - KV" ("A1", "B1", "C1") FROM '$$PATH$$/3994.dat';

--
-- Data for Name: רשפ תעסוקה לא בכח העבודה-מספר האנש; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה לא בכח העבודה-מספר האנש" ("A1", "B1", "C1", "D1", "E1", "F1") FROM stdin;
\.
COPY public."רשפ תעסוקה לא בכח העבודה-מספר האנש" ("A1", "B1", "C1", "D1", "E1", "F1") FROM '$$PATH$$/4032.dat';

--
-- Data for Name: רשפ תעסוקה לא בכח העבודה-שיעור מתו; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה לא בכח העבודה-שיעור מתו" ("A1", "B1", "C1", "D1", "E1") FROM stdin;
\.
COPY public."רשפ תעסוקה לא בכח העבודה-שיעור מתו" ("A1", "B1", "C1", "D1", "E1") FROM '$$PATH$$/4031.dat';

--
-- Data for Name: רשפ תעסוקה מועסקים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM stdin;
\.
COPY public."רשפ תעסוקה מועסקים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM '$$PATH$$/4025.dat';

--
-- Data for Name: רשפ תעסוקה מועסקים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM stdin;
\.
COPY public."רשפ תעסוקה מועסקים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1") FROM '$$PATH$$/4026.dat';

--
-- Data for Name: רשפ תעסוקה סקטור-מספר מועסקים בסקט; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה סקטור-מספר מועסקים בסקט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM stdin;
\.
COPY public."רשפ תעסוקה סקטור-מספר מועסקים בסקט" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1") FROM '$$PATH$$/4054.dat';

--
-- Data for Name: רשפ תעסוקה סקטור-שיעור מועסקים בסק; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."רשפ תעסוקה סקטור-שיעור מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."רשפ תעסוקה סקטור-שיעור מועסקים בסק" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4053.dat';

--
-- Data for Name: שינוי ביחס לרבעון הקודם תמג לנפש ר; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שינוי ביחס לרבעון הקודם תמג לנפש ר" ("A1", "B1", "C1", "D1") FROM stdin;
\.
COPY public."שינוי ביחס לרבעון הקודם תמג לנפש ר" ("A1", "B1", "C1", "D1") FROM '$$PATH$$/3999.dat';

--
-- Data for Name: שינוי במחיירם ברצע ביחס לחודש הקוד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שינוי במחיירם ברצע ביחס לחודש הקוד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."שינוי במחיירם ברצע ביחס לחודש הקוד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3985.dat';

--
-- Data for Name: שינוי במחירים ברצע ביחס לאשתקד; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שינוי במחירים ברצע ביחס לאשתקד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."שינוי במחירים ברצע ביחס לאשתקד" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3983.dat';

--
-- Data for Name: שינוי במחירים ברצע ביחס לאשתקד - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שינוי במחירים ברצע ביחס לאשתקד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM stdin;
\.
COPY public."שינוי במחירים ברצע ביחס לאשתקד - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1") FROM '$$PATH$$/3984.dat';

--
-- Data for Name: שינוי במחירים ברשפ ביחס לחודש המקב; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שינוי במחירים ברשפ ביחס לחודש המקב" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM stdin;
\.
COPY public."שינוי במחירים ברשפ ביחס לחודש המקב" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1") FROM '$$PATH$$/3988.dat';

--
-- Data for Name: שכר יומי ממוצע שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שכר יומי ממוצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM stdin;
\.
COPY public."שכר יומי ממוצע שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM '$$PATH$$/3989.dat';

--
-- Data for Name: שכר יומי ממוצע שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שכר יומי ממוצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM stdin;
\.
COPY public."שכר יומי ממוצע שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1", "T1", "U1") FROM '$$PATH$$/3990.dat';

--
-- Data for Name: שנתי ייצור תעשייתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שנתי ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM stdin;
\.
COPY public."שנתי ייצור תעשייתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM '$$PATH$$/3991.dat';

--
-- Data for Name: שנתי ייצור תעשייתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."שנתי ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM stdin;
\.
COPY public."שנתי ייצור תעשייתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1") FROM '$$PATH$$/3992.dat';

--
-- Data for Name: תוצר לנפש שנתי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תוצר לנפש שנתי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/4000.dat';

--
-- Data for Name: תוצר לנפש שנתי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תוצר לנפש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תוצר לנפש שנתי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/4001.dat';

--
-- Data for Name: תעסוקה איוש גברים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4008.dat';

--
-- Data for Name: תעסוקה איוש גברים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4009.dat';

--
-- Data for Name: תעסוקה איוש מרכזי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4041.dat';

--
-- Data for Name: תעסוקה איוש מרכזי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4042.dat';

--
-- Data for Name: תעסוקה איוש נשים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4049.dat';

--
-- Data for Name: תעסוקה איוש נשים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה איוש נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה איוש נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4050.dat';

--
-- Data for Name: תעסוקה בישראל; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה בישראל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תעסוקה בישראל" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/4002.dat';

--
-- Data for Name: תעסוקה בישראל - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה בישראל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM stdin;
\.
COPY public."תעסוקה בישראל - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1") FROM '$$PATH$$/4003.dat';

--
-- Data for Name: תעסוקה ישראל והתיישבות מרכזי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה ישראל והתיישבות מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה ישראל והתיישבות מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4043.dat';

--
-- Data for Name: תעסוקה ישראל והתיישבות מרכזי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה ישראל והתיישבות מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM stdin;
\.
COPY public."תעסוקה ישראל והתיישבות מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1") FROM '$$PATH$$/4044.dat';

--
-- Data for Name: תעסוקה נתונים שנתיים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נתונים שנתיים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."תעסוקה נתונים שנתיים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4051.dat';

--
-- Data for Name: תעסוקה נתונים שנתיים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה נתונים שנתיים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM stdin;
\.
COPY public."תעסוקה נתונים שנתיים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1", "M1", "N1", "O1", "P1", "Q1", "R1", "S1") FROM '$$PATH$$/4052.dat';

--
-- Data for Name: תעסוקה רצע גברים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4006.dat';

--
-- Data for Name: תעסוקה רצע גברים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4007.dat';

--
-- Data for Name: תעסוקה רצע מרכזי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4039.dat';

--
-- Data for Name: תעסוקה רצע מרכזי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4040.dat';

--
-- Data for Name: תעסוקה רצע נשים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4047.dat';

--
-- Data for Name: תעסוקה רצע נשים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רצע נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רצע נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4048.dat';

--
-- Data for Name: תעסוקה רשפ גברים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ גברים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4004.dat';

--
-- Data for Name: תעסוקה רשפ גברים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ גברים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4005.dat';

--
-- Data for Name: תעסוקה רשפ מרכזי; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ מרכזי" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4037.dat';

--
-- Data for Name: תעסוקה רשפ מרכזי - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ מרכזי - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4038.dat';

--
-- Data for Name: תעסוקה רשפ נשים; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ נשים" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4045.dat';

--
-- Data for Name: תעסוקה רשפ נשים - KV; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."תעסוקה רשפ נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM stdin;
\.
COPY public."תעסוקה רשפ נשים - KV" ("A1", "B1", "C1", "D1", "E1", "F1", "G1", "H1", "I1", "J1", "K1", "L1") FROM '$$PATH$$/4046.dat';

--
-- PostgreSQL database dump complete
--

