--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dashboardsdb;
--
-- Name: dashboardsdb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE dashboardsdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Israel.1252' LC_CTYPE = 'English_Israel.1252';


ALTER DATABASE dashboardsdb OWNER TO matpash;

\connect dashboardsdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: graphsInfoTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."graphsInfoTable" (
    index integer NOT NULL,
    "position" text,
    width integer,
    height integer,
    "xPos" integer,
    "yPos" integer,
    "layoutIndex" integer,
    type text NOT NULL,
    title text NOT NULL,
    subtitle text,
    "xAxisTitle" text,
    "yAxisTitle" text,
    "xAxisColumn" text,
    "yAxisColumn" text,
    "xAxisCatagoryRange" text,
    "yAxisCatagoryRange" text,
    legend boolean,
    "flipXAxis" boolean,
    info text
);


ALTER TABLE public."graphsInfoTable" OWNER TO postgres;

--
-- Data for Name: graphsInfoTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis", info) FROM stdin;
\.
COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis", info) FROM '$$PATH$$/2845.dat';

--
-- Name: graphsInfoTable graphsInfoTable_INDEX_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."graphsInfoTable"
    ADD CONSTRAINT "graphsInfoTable_INDEX_pkey" PRIMARY KEY (index);


--
-- PostgreSQL database dump complete
--

