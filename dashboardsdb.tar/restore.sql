--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dashboardsdb;
--
-- Name: dashboardsdb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE dashboardsdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_Israel.1252' LC_CTYPE = 'English_Israel.1252';


ALTER DATABASE dashboardsdb OWNER TO matpash;

\connect dashboardsdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboard2Series; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboard2Series" (
    index integer NOT NULL,
    "serieName" text NOT NULL,
    "serieRange" text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public."dashboard2Series" OWNER TO matpash;

--
-- Name: dashboard3Series; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboard3Series" (
    index integer NOT NULL,
    "serieName" text NOT NULL,
    "serieRange" text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public."dashboard3Series" OWNER TO matpash;

--
-- Name: dashboard4Series; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboard4Series" (
    index integer NOT NULL,
    "serieName" text NOT NULL,
    "serieRange" text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public."dashboard4Series" OWNER TO matpash;

--
-- Name: dashboard5Series; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboard5Series" (
    index integer NOT NULL,
    "serieName" text NOT NULL,
    "serieRange" text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public."dashboard5Series" OWNER TO matpash;

--
-- Name: dashboardNames; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboardNames" (
    index integer NOT NULL,
    name text NOT NULL,
    lastupdate text
);


ALTER TABLE public."dashboardNames" OWNER TO matpash;

--
-- Name: dashboardPriviledgesTable; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboardPriviledgesTable" (
    username text NOT NULL,
    dashboard2 text,
    dashboard3 text,
    dashboard4 text,
    dashboard5 text
);


ALTER TABLE public."dashboardPriviledgesTable" OWNER TO matpash;

--
-- Name: goldenDataTable; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."goldenDataTable" (
    index integer NOT NULL,
    "subTitle" text,
    seriename text,
    period text,
    cmpperiod text
);


ALTER TABLE public."goldenDataTable" OWNER TO matpash;

--
-- Name: goldenLayoutTable; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."goldenLayoutTable" (
    index integer NOT NULL,
    title text,
    valuetype text,
    width integer,
    height double precision,
    "xPos" integer,
    "yPos" integer,
    "actionType" text
);


ALTER TABLE public."goldenLayoutTable" OWNER TO matpash;

--
-- Name: graphsInfoTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."graphsInfoTable" (
    index integer NOT NULL,
    "position" text,
    width integer,
    height integer,
    "xPos" integer,
    "yPos" integer,
    "layoutIndex" integer,
    type text NOT NULL,
    title text NOT NULL,
    subtitle text,
    "xAxisTitle" text,
    "yAxisTitle" text,
    "xAxisColumn" text,
    "yAxisColumn" text,
    "xAxisCatagoryRange" text,
    "yAxisCatagoryRange" text,
    legend boolean,
    "flipXAxis" boolean,
    info text
);


ALTER TABLE public."graphsInfoTable" OWNER TO postgres;

--
-- Data for Name: dashboard2Series; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboard2Series" (index, "serieName", "serieRange", color) FROM stdin;
\.
COPY public."dashboard2Series" (index, "serieName", "serieRange", color) FROM '$$PATH$$/2860.dat';

--
-- Data for Name: dashboard3Series; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboard3Series" (index, "serieName", "serieRange", color) FROM stdin;
\.
COPY public."dashboard3Series" (index, "serieName", "serieRange", color) FROM '$$PATH$$/2861.dat';

--
-- Data for Name: dashboard4Series; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboard4Series" (index, "serieName", "serieRange", color) FROM stdin;
\.
COPY public."dashboard4Series" (index, "serieName", "serieRange", color) FROM '$$PATH$$/2862.dat';

--
-- Data for Name: dashboard5Series; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboard5Series" (index, "serieName", "serieRange", color) FROM stdin;
\.
COPY public."dashboard5Series" (index, "serieName", "serieRange", color) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: dashboardNames; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboardNames" (index, name, lastupdate) FROM stdin;
\.
COPY public."dashboardNames" (index, name, lastupdate) FROM '$$PATH$$/2863.dat';

--
-- Data for Name: dashboardPriviledgesTable; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboardPriviledgesTable" (username, dashboard2, dashboard3, dashboard4, dashboard5) FROM stdin;
\.
COPY public."dashboardPriviledgesTable" (username, dashboard2, dashboard3, dashboard4, dashboard5) FROM '$$PATH$$/2864.dat';

--
-- Data for Name: goldenDataTable; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."goldenDataTable" (index, "subTitle", seriename, period, cmpperiod) FROM stdin;
\.
COPY public."goldenDataTable" (index, "subTitle", seriename, period, cmpperiod) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: goldenLayoutTable; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."goldenLayoutTable" (index, title, valuetype, width, height, "xPos", "yPos", "actionType") FROM stdin;
\.
COPY public."goldenLayoutTable" (index, title, valuetype, width, height, "xPos", "yPos", "actionType") FROM '$$PATH$$/2866.dat';

--
-- Data for Name: graphsInfoTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis", info) FROM stdin;
\.
COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis", info) FROM '$$PATH$$/2867.dat';

--
-- Name: dashboardPriviledgesTable dashboardPriviledgesTable_USERNAME_key; Type: CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboardPriviledgesTable"
    ADD CONSTRAINT "dashboardPriviledgesTable_USERNAME_key" UNIQUE (username);


--
-- Name: graphsInfoTable graphsInfoTable_INDEX_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."graphsInfoTable"
    ADD CONSTRAINT "graphsInfoTable_INDEX_pkey" PRIMARY KEY (index);


--
-- Name: dashboard2Series fk_index; Type: FK CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboard2Series"
    ADD CONSTRAINT fk_index FOREIGN KEY (index) REFERENCES public."graphsInfoTable"(index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard3Series fk_index; Type: FK CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboard3Series"
    ADD CONSTRAINT fk_index FOREIGN KEY (index) REFERENCES public."graphsInfoTable"(index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard4Series fk_index; Type: FK CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboard4Series"
    ADD CONSTRAINT fk_index FOREIGN KEY (index) REFERENCES public."graphsInfoTable"(index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard5Series fk_index; Type: FK CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboard5Series"
    ADD CONSTRAINT fk_index FOREIGN KEY (index) REFERENCES public."graphsInfoTable"(index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

