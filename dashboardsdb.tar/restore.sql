--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dashboardsdb;
--
-- Name: dashboardsdb; Type: DATABASE; Schema: -; Owner: matpash
--

CREATE DATABASE dashboardsdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE dashboardsdb OWNER TO matpash;

\connect dashboardsdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboard1Series; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboard1Series" (
    index integer NOT NULL,
    "serieName" text NOT NULL,
    "serieRange" text NOT NULL,
    color text NOT NULL
);


ALTER TABLE public."dashboard1Series" OWNER TO matpash;

--
-- Name: dashboardNames; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboardNames" (
    index integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."dashboardNames" OWNER TO matpash;

--
-- Name: dashboardPriviledgesTable; Type: TABLE; Schema: public; Owner: matpash
--

CREATE TABLE public."dashboardPriviledgesTable" (
    username text NOT NULL,
    dashboard1 text
);


ALTER TABLE public."dashboardPriviledgesTable" OWNER TO matpash;

--
-- Name: graphsInfoTable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."graphsInfoTable" (
    index integer NOT NULL,
    "position" text,
    width integer,
    height integer,
    "xPos" integer,
    "yPos" integer,
    "layoutIndex" integer,
    type text NOT NULL,
    title text NOT NULL,
    subtitle text,
    "xAxisTitle" text,
    "yAxisTitle" text,
    "xAxisColumn" text,
    "yAxisColumn" text,
    "xAxisCatagoryRange" text,
    "yAxisCatagoryRange" text,
    legend boolean,
    "flipXAxis" boolean
);


ALTER TABLE public."graphsInfoTable" OWNER TO postgres;

--
-- Data for Name: dashboard1Series; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboard1Series" (index, "serieName", "serieRange", color) FROM stdin;
\.
COPY public."dashboard1Series" (index, "serieName", "serieRange", color) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: dashboardNames; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboardNames" (index, name) FROM stdin;
\.
COPY public."dashboardNames" (index, name) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: dashboardPriviledgesTable; Type: TABLE DATA; Schema: public; Owner: matpash
--

COPY public."dashboardPriviledgesTable" (username, dashboard1) FROM stdin;
\.
COPY public."dashboardPriviledgesTable" (username, dashboard1) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: graphsInfoTable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis") FROM stdin;
\.
COPY public."graphsInfoTable" (index, "position", width, height, "xPos", "yPos", "layoutIndex", type, title, subtitle, "xAxisTitle", "yAxisTitle", "xAxisColumn", "yAxisColumn", "xAxisCatagoryRange", "yAxisCatagoryRange", legend, "flipXAxis") FROM '$$PATH$$/2835.dat';

--
-- Name: dashboardPriviledgesTable dashboardPriviledgesTable_USERNAME_key; Type: CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboardPriviledgesTable"
    ADD CONSTRAINT "dashboardPriviledgesTable_USERNAME_key" UNIQUE (username);


--
-- Name: graphsInfoTable graphsInfoTable_INDEX_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."graphsInfoTable"
    ADD CONSTRAINT "graphsInfoTable_INDEX_pkey" PRIMARY KEY (index);


--
-- Name: dashboard1Series fk_index; Type: FK CONSTRAINT; Schema: public; Owner: matpash
--

ALTER TABLE ONLY public."dashboard1Series"
    ADD CONSTRAINT fk_index FOREIGN KEY (index) REFERENCES public."graphsInfoTable"(index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

